"""
DISASTER KIT CHECKLIST
A beginner-friendly Python terminal project.

Run:
    python disaster_kit.py

Data is stored locally in disaster_kit.json.
No third-party packages are required.
"""

import csv
import json
from datetime import date, datetime, timedelta
from pathlib import Path

DATA_FILE = Path(__file__).with_name("disaster_kit.json")
DATE_FORMAT = "%Y-%m-%d"
CATEGORIES = [
    "Food & Water", "Medical", "Tools & Lighting", "Communication",
    "Clothing & Shelter", "Documents", "Hygiene", "Special Needs", "Other"
]
PRIORITIES = ["High", "Medium", "Low"]
STATUSES = ["Pending", "Completed"]


def load_items():
    """Load saved checklist data. Start with an empty list if unavailable."""
    if not DATA_FILE.exists():
        return []
    try:
        with DATA_FILE.open("r", encoding="utf-8") as file:
            items = json.load(file)
        if not isinstance(items, list):
            print("Warning: data file format is incorrect. Starting with an empty list.")
            return []
        return items
    except (json.JSONDecodeError, OSError):
        print("Warning: could not read the data file. Starting with an empty list.")
        return []


def save_items(items):
    """Save all checklist records to the local JSON file."""
    try:
        with DATA_FILE.open("w", encoding="utf-8") as file:
            json.dump(items, file, indent=4)
        return True
    except OSError as error:
        print(f"Could not save data: {error}")
        return False


def read_non_empty(prompt):
    """Keep asking until the user enters non-blank text."""
    while True:
        value = input(prompt).strip()
        if value:
            return value
        print("Input cannot be blank. Please try again.")


def read_choice(prompt, choices):
    """Read a value from a fixed list, ignoring letter case."""
    while True:
        value = input(prompt).strip()
        for choice in choices:
            if value.lower() == choice.lower():
                return choice
        print("Please choose: " + ", ".join(choices))


def read_quantity():
    """Read a positive whole number."""
    while True:
        try:
            value = int(input("Quantity (positive whole number): ").strip())
            if value > 0:
                return value
            print("Quantity must be greater than zero.")
        except ValueError:
            print("Please enter a valid whole number.")


def read_expiry_date():
    """Read an optional date in YYYY-MM-DD format."""
    while True:
        value = input("Expiry date (YYYY-MM-DD, or press Enter if not applicable): ").strip()
        if not value:
            return ""
        try:
            datetime.strptime(value, DATE_FORMAT)
            return value
        except ValueError:
            print("Invalid date. Example: 2027-05-31")


def next_id(items):
    return max((item.get("id", 0) for item in items), default=0) + 1


def print_table(items):
    """Display records in a readable terminal table."""
    if not items:
        print("\nNo checklist items found.")
        return

    headers = ("ID", "ITEM", "CATEGORY", "QTY", "PRIORITY", "STATUS", "EXPIRY")
    rows = []
    for item in items:
        rows.append((
            str(item.get("id", "")),
            str(item.get("name", ""))[:22],
            str(item.get("category", ""))[:18],
            str(item.get("quantity", "")),
            str(item.get("priority", "")),
            str(item.get("status", "")),
            str(item.get("expiry_date", "")) or "-"
        ))

    widths = [4, 22, 18, 5, 9, 11, 12]
    line = "-+-".join("-" * width for width in widths)
    print()
    print(" | ".join(headers[i].ljust(widths[i]) for i in range(len(headers))))
    print(line)
    for row in rows:
        print(" | ".join(row[i].ljust(widths[i]) for i in range(len(row))))


def add_item(items):
    print("\n--- ADD A CHECKLIST ITEM ---")
    name = read_non_empty("Item name: ")
    print("Categories: " + ", ".join(CATEGORIES))
    category = read_choice("Category: ", CATEGORIES)
    quantity = read_quantity()
    priority = read_choice("Priority (High/Medium/Low): ", PRIORITIES)
    status = read_choice("Status (Pending/Completed): ", STATUSES)
    expiry_date = read_expiry_date()

    item = {
        "id": next_id(items),
        "name": name,
        "category": category,
        "quantity": quantity,
        "priority": priority,
        "status": status,
        "expiry_date": expiry_date
    }
    items.append(item)
    if save_items(items):
        print("Item added and saved successfully.")


def update_status(items):
    print_table(items)
    if not items:
        return
    try:
        item_id = int(input("\nEnter the ID to update: ").strip())
    except ValueError:
        print("Please enter a valid numeric ID.")
        return

    for item in items:
        if item.get("id") == item_id:
            item["status"] = read_choice("New status (Pending/Completed): ", STATUSES)
            if save_items(items):
                print("Status updated successfully.")
            return
    print("No item exists with that ID.")


def search_items(items):
    print("\n--- SEARCH CHECKLIST ---")
    keyword = read_non_empty("Enter item name or category keyword: ").lower()
    matches = [
        item for item in items
        if keyword in item.get("name", "").lower()
        or keyword in item.get("category", "").lower()
    ]
    print_table(matches)


def show_summary(items):
    total = len(items)
    completed = sum(1 for item in items if item.get("status") == "Completed")
    pending = total - completed
    total_quantity = sum(
        item.get("quantity", 0) for item in items
        if isinstance(item.get("quantity", 0), (int, float))
    )
    high_priority_pending = sum(
        1 for item in items
        if item.get("priority") == "High" and item.get("status") != "Completed"
    )
    completion = (completed / total * 100) if total else 0

    print("\n========== PROJECT SUMMARY ==========")
    print(f"Total different items : {total}")
    print(f"Total quantity        : {total_quantity}")
    print(f"Completed items       : {completed}")
    print(f"Pending items         : {pending}")
    print(f"Completion percentage : {completion:.1f}%")
    print(f"High-priority pending : {high_priority_pending}")
    print("=====================================")


def show_warnings(items):
    """Show expired or soon-to-expire items, plus pending high-priority items."""
    today = date.today()
    limit = today + timedelta(days=30)
    found = False
    print("\n--- ALERTS ---")
    for item in items:
        expiry = item.get("expiry_date", "")
        if expiry:
            try:
                expiry_day = datetime.strptime(expiry, DATE_FORMAT).date()
                if expiry_day < today:
                    print(f"EXPIRED: {item['name']} (date: {expiry})")
                    found = True
                elif expiry_day <= limit:
                    print(f"EXPIRING SOON: {item['name']} (date: {expiry})")
                    found = True
            except (ValueError, TypeError):
                print(f"CHECK DATE: {item.get('name', 'Unknown item')} has an invalid expiry date.")
                found = True
        if item.get("priority") == "High" and item.get("status") == "Pending":
            print(f"HIGH PRIORITY PENDING: {item.get('name', 'Unknown item')}")
            found = True
    if not found:
        print("No alerts at this time.")


def export_csv(items):
    output = Path(__file__).with_name("disaster_kit_report.csv")
    fields = ["id", "name", "category", "quantity", "priority", "status", "expiry_date"]
    try:
        with output.open("w", newline="", encoding="utf-8") as file:
            writer = csv.DictWriter(file, fieldnames=fields)
            writer.writeheader()
            writer.writerows(items)
        print(f"CSV report created: {output.name}")
    except OSError as error:
        print(f"Could not export CSV: {error}")


def export_text_report(items):
    output = Path(__file__).with_name("disaster_kit_report.txt")
    completed = sum(1 for item in items if item.get("status") == "Completed")
    lines = [
        "DISASTER KIT CHECKLIST REPORT",
        "=" * 32,
        f"Generated: {date.today().isoformat()}",
        f"Total items: {len(items)}",
        f"Completed: {completed}",
        f"Pending: {len(items) - completed}",
        "",
        "ITEM DETAILS",
        "-" * 32
    ]
    for item in items:
        lines.append(
            f"{item.get('id')}. {item.get('name')} | {item.get('category')} | "
            f"Qty: {item.get('quantity')} | {item.get('priority')} | "
            f"{item.get('status')} | Expiry: {item.get('expiry_date') or 'N/A'}"
        )
    try:
        output.write_text("\n".join(lines), encoding="utf-8")
        print(f"Text report created: {output.name}")
    except OSError as error:
        print(f"Could not create report: {error}")


def delete_item(items):
    print_table(items)
    if not items:
        return
    try:
        item_id = int(input("\nEnter the ID to delete: ").strip())
    except ValueError:
        print("Please enter a valid numeric ID.")
        return
    for index, item in enumerate(items):
        if item.get("id") == item_id:
            confirm = read_choice(f"Delete '{item.get('name')}'? (yes/no): ", ["yes", "no"])
            if confirm == "yes":
                del items[index]
                if save_items(items):
                    print("Item deleted.")
            else:
                print("Delete cancelled.")
            return
    print("No item exists with that ID.")


def main():
    items = load_items()
    while True:
        print("\n" + "=" * 48)
        print("          DISASTER KIT CHECKLIST")
        print("       Be prepared. Stay safe.")
        print("=" * 48)
        print("1. View all checklist items")
        print("2. Add a new item")
        print("3. Update item status")
        print("4. Search by item or category")
        print("5. View project summary")
        print("6. Show warnings and alerts")
        print("7. Export CSV report")
        print("8. Export text report")
        print("9. Delete an item")
        print("0. Save and exit")

        choice = input("\nEnter your choice (0-9): ").strip()
        if choice == "1":
            print_table(items)
        elif choice == "2":
            add_item(items)
        elif choice == "3":
            update_status(items)
        elif choice == "4":
            search_items(items)
        elif choice == "5":
            show_summary(items)
        elif choice == "6":
            show_warnings(items)
        elif choice == "7":
            export_csv(items)
        elif choice == "8":
            export_text_report(items)
        elif choice == "9":
            delete_item(items)
        elif choice == "0":
            save_items(items)
            print("Your checklist is saved. Thank you for using the project!")
            break
        else:
            print("Invalid choice. Please enter a number from 0 to 9.")


if __name__ == "__main__":
    main()
