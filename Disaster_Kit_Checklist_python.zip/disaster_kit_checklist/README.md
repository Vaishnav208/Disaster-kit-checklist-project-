# Disaster Kit Checklist — Python Mini Project

## About
A menu-driven Python application for recording emergency supplies, tracking whether items are ready, searching the checklist, reviewing summary metrics, checking alerts, and exporting reports.

## Requirements
- Python 3.10 or later
- No third-party packages

## How to run
1. Extract the ZIP file.
2. Open the extracted `disaster_kit_checklist` folder.
3. Open Command Prompt or a terminal in that folder.
4. Run:

   `python disaster_kit.py`

   On some Windows computers, use `py disaster_kit.py`.

## Files
- `disaster_kit.py` — the complete Python program.
- `disaster_kit.json` — sample checklist data (35 records). The program updates this file when you add, update, or delete records.
- `README.md` — project instructions.

## Menu features
1. View all items.
2. Add a new item with category, quantity, priority, status, and optional expiry date.
3. Update an item's status to Pending or Completed.
4. Search item names and categories.
5. View totals, completion percentage, and high-priority pending count.
6. Check expired/soon-to-expire dates and high-priority pending items.
7. Export a CSV report.
8. Export a plain-text report.
9. Delete an item.
0. Save and exit.

## Data safety
The program stores data locally in JSON. Keep a backup copy of `disaster_kit.json` if the checklist is important. Expiry alerts are reminders based on dates entered by the user; they do not replace official emergency-preparedness advice.
