import React from 'react';
import { Download } from 'lucide-react';
import { KIT_PRIORITIES, SummaryMetrics } from '../types/checklist';
import { CategoryIcon } from './CategoryIcon';

interface SummaryViewProps {
  metrics: SummaryMetrics;
  onGoToExport: () => void;
}

export const SummaryView: React.FC<SummaryViewProps> = ({ metrics, onGoToExport }) => {
  const radius = 44;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset =
    circumference - (metrics.overallCompletionRate / 100) * circumference;

  return (
    <div className="space-y-5">
      {/* Top Executive KPI Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Signature Dark Slate Readiness Ring Card */}
        <section className="bg-slate-900 text-white border border-slate-800 rounded-2xl p-5 flex items-center gap-5">
          <div className="relative w-28 h-28 shrink-0 flex items-center justify-center">
            <svg className="w-28 h-28 -rotate-90" viewBox="0 0 104 104" aria-hidden="true">
              <circle
                cx="52"
                cy="52"
                r={radius}
                fill="none"
                stroke="rgba(255,255,255,0.14)"
                strokeWidth="10"
              />
              <circle
                cx="52"
                cy="52"
                r={radius}
                fill="none"
                stroke="#F97316"
                strokeWidth="10"
                strokeLinecap="round"
                strokeDasharray={circumference}
                strokeDashoffset={strokeDashoffset}
                className="transition-all duration-300"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-2xl font-bold font-mono tabular-nums text-white">
                {metrics.overallCompletionRate}%
              </span>
              <span className="text-[11px] text-slate-300">Complete</span>
            </div>
          </div>

          <div className="min-w-0">
            <h2 className="text-base font-bold text-white">Executive Readiness</h2>
            <p className="text-xs text-slate-300 mt-1">
              {metrics.completedItems} of {metrics.totalItems} checklist items verified
            </p>
            <p className="text-xs text-orange-300 font-mono tabular-nums mt-2">
              Avg unit fill: {metrics.averageItemReadiness}%
            </p>
          </div>
        </section>

        {/* Key Numeric Totals */}
        <section className="lg:col-span-2 bg-white border border-slate-200 rounded-2xl p-5 grid grid-cols-2 sm:grid-cols-4 gap-4 items-center">
          <div>
            <p className="text-xs text-slate-500">Critical Readiness</p>
            <p className="text-2xl font-bold font-mono tabular-nums text-slate-900 mt-1">
              {metrics.criticalReadinessRate}%
            </p>
            <p className="text-xs text-slate-500 font-mono tabular-nums mt-0.5">
              {metrics.criticalCompleted}/{metrics.criticalTotal} critical
            </p>
          </div>

          <div>
            <p className="text-xs text-slate-500">Units Packed</p>
            <p className="text-2xl font-bold font-mono tabular-nums text-slate-900 mt-1">
              {metrics.totalPackedUnits}
            </p>
            <p className="text-xs text-slate-500 font-mono tabular-nums mt-0.5">
              of {metrics.totalTargetUnits} target
            </p>
          </div>

          <div>
            <p className="text-xs text-slate-500">Overdue Items</p>
            <p
              className={`text-2xl font-bold font-mono tabular-nums mt-1 ${
                metrics.overdueCount > 0 ? 'text-rose-700' : 'text-emerald-700'
              }`}
            >
              {metrics.overdueCount}
            </p>
            <p className="text-xs text-slate-500 mt-0.5">
              {metrics.expiringSoonCount} expiring ≤30d
            </p>
          </div>

          <div>
            <p className="text-xs text-slate-500">Critical Stock Gaps</p>
            <p
              className={`text-2xl font-bold font-mono tabular-nums mt-1 ${
                metrics.criticalGapCount > 0 ? 'text-amber-700' : 'text-emerald-700'
              }`}
            >
              {metrics.criticalGapCount}
            </p>
            <p className="text-xs text-slate-500 mt-0.5">
              {metrics.anomalyCount} anomalies
            </p>
          </div>
        </section>
      </div>

      {/* Category Readiness Chart + Priority Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        <section className="lg:col-span-2 bg-white border border-slate-200 rounded-2xl p-5">
          <div className="flex items-center justify-between gap-4 mb-5">
            <div>
              <h2 className="text-base font-bold text-slate-900">Category Readiness</h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Completion percentage and packed unit coverage by supply domain
              </p>
            </div>
            <button
              type="button"
              onClick={onGoToExport}
              className="min-h-[40px] px-3.5 py-2 text-xs font-semibold text-slate-700 border border-slate-300 hover:bg-slate-50 rounded-xl inline-flex items-center gap-1.5 whitespace-nowrap shrink-0"
            >
              <Download className="w-3.5 h-3.5" aria-hidden="true" />
              <span>Export Report</span>
            </button>
          </div>

          <div className="space-y-4">
            {metrics.byCategory.map((cat) => (
              <div key={cat.category} className="flex items-center gap-3">
                <CategoryIcon category={cat.category} />
                <div className="flex-1 min-w-0 space-y-1.5">
                  <div className="flex items-center justify-between text-xs sm:text-sm gap-2">
                    <span className="font-medium text-slate-800 truncate">{cat.category}</span>
                    <div className="flex items-center gap-3 font-mono tabular-nums text-xs text-slate-600 shrink-0">
                      <span>
                        {cat.completedItems}/{cat.totalItems} items
                      </span>
                      <span className="font-semibold text-slate-900 w-10 text-right">
                        {cat.completionRate}%
                      </span>
                    </div>
                  </div>
                  <div className="h-2.5 w-full bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-300 ${
                        cat.completionRate === 100
                          ? 'bg-emerald-600'
                          : cat.completionRate >= 60
                          ? 'bg-orange-600'
                          : 'bg-rose-600'
                      }`}
                      style={{ width: `${cat.completionRate}%` }}
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Priority Tier Breakdown */}
        <section className="bg-white border border-slate-200 rounded-2xl p-5 flex flex-col justify-between">
          <div>
            <h2 className="text-base font-bold text-slate-900">Priority Tier Status</h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Preparedness distribution across urgency tiers
            </p>

            <div className="mt-5 space-y-4">
              {KIT_PRIORITIES.map((priority) => {
                const stats = metrics.byPriority[priority];
                const barColor =
                  priority === 'Critical'
                    ? 'bg-rose-600'
                    : priority === 'Essential'
                    ? 'bg-orange-600'
                    : 'bg-slate-600';

                return (
                  <div key={priority} className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-semibold text-slate-900">{priority}</span>
                      <span className="text-sm font-mono tabular-nums font-bold text-slate-900">
                        {stats.rate}%
                      </span>
                    </div>
                    <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-300 ${barColor}`}
                        style={{ width: `${stats.rate}%` }}
                      />
                    </div>
                    <div className="flex items-center justify-between text-xs text-slate-500 font-mono tabular-nums">
                      <span>{stats.completed} packed</span>
                      <span>{stats.total} total items</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <p className="mt-5 pt-4 border-t border-slate-100 text-xs text-slate-500 leading-relaxed">
            Prioritize resolving Critical gaps and overdue items before expanding Recommended reserves.
          </p>
        </section>
      </div>

      {/* Tabular Category Summary Table */}
      <section className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-200">
          <h2 className="text-base font-bold text-slate-900">Category Summary Table</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600">
                <th className="py-3 px-4 sm:px-5">Category</th>
                <th className="py-3 px-4 text-right">Items</th>
                <th className="py-3 px-4 text-right">Completed</th>
                <th className="py-3 px-4 text-right">Completion %</th>
                <th className="py-3 px-4 sm:px-5 text-right">Units (Packed / Target)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-sm">
              {metrics.byCategory.map((row) => (
                <tr key={row.category} className="hover:bg-slate-50/70">
                  <td className="py-3 px-4 sm:px-5 font-medium text-slate-900">{row.category}</td>
                  <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-700">
                    {row.totalItems}
                  </td>
                  <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-700">
                    {row.completedItems}
                  </td>
                  <td className="py-3 px-4 text-right font-mono tabular-nums font-semibold text-slate-900">
                    {row.completionRate}%
                  </td>
                  <td className="py-3 px-4 sm:px-5 text-right font-mono tabular-nums text-slate-700">
                    {row.totalPackedUnits} / {row.totalTargetUnits}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
};
