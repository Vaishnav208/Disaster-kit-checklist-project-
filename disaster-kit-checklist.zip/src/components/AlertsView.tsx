import React, { useMemo, useState } from 'react';
import { AlertCircle, AlertTriangle, CheckCircle2, Info, Pencil } from 'lucide-react';
import { AlertType, KitItem, ThresholdAlert } from '../types/checklist';

interface AlertsViewProps {
  alerts: ThresholdAlert[];
  items: KitItem[];
  onEditItem: (item: KitItem) => void;
}

export const AlertsView: React.FC<AlertsViewProps> = ({ alerts, items, onEditItem }) => {
  const [filterType, setFilterType] = useState<AlertType | 'all'>('all');

  const itemsById = useMemo(() => new Map(items.map((i) => [i.id, i])), [items]);

  const filteredAlerts = useMemo(() => {
    if (filterType === 'all') return alerts;
    return alerts.filter((a) => a.type === filterType);
  }, [alerts, filterType]);

  const counts = useMemo(
    () => ({
      all: alerts.length,
      overdue: alerts.filter((a) => a.type === 'overdue').length,
      critical_gap: alerts.filter((a) => a.type === 'critical_gap').length,
      expiring_soon: alerts.filter((a) => a.type === 'expiring_soon').length,
      anomaly: alerts.filter((a) => a.type === 'anomaly').length,
    }),
    [alerts]
  );

  return (
    <div className="space-y-5">
      {/* Severity Summary Strip */}
      <div className="grid grid-cols-3 gap-3 sm:gap-4">
        <button
          type="button"
          onClick={() => setFilterType(filterType === 'overdue' ? 'all' : 'overdue')}
          className={`text-left bg-white border rounded-2xl p-4 transition-colors ${
            filterType === 'overdue'
              ? 'border-rose-400 ring-2 ring-rose-100'
              : 'border-slate-200 hover:border-slate-300'
          }`}
        >
          <div className="text-xs text-slate-500">Overdue</div>
          <div className="text-2xl font-bold font-mono tabular-nums text-rose-700 mt-1">
            {counts.overdue}
          </div>
        </button>

        <button
          type="button"
          onClick={() => setFilterType(filterType === 'critical_gap' ? 'all' : 'critical_gap')}
          className={`text-left bg-white border rounded-2xl p-4 transition-colors ${
            filterType === 'critical_gap'
              ? 'border-amber-400 ring-2 ring-amber-100'
              : 'border-slate-200 hover:border-slate-300'
          }`}
        >
          <div className="text-xs text-slate-500">Critical Gaps</div>
          <div className="text-2xl font-bold font-mono tabular-nums text-amber-700 mt-1">
            {counts.critical_gap}
          </div>
        </button>

        <button
          type="button"
          onClick={() => setFilterType(filterType === 'expiring_soon' ? 'all' : 'expiring_soon')}
          className={`text-left bg-white border rounded-2xl p-4 transition-colors ${
            filterType === 'expiring_soon'
              ? 'border-slate-400 ring-2 ring-slate-200'
              : 'border-slate-200 hover:border-slate-300'
          }`}
        >
          <div className="text-xs text-slate-500">Expiring ≤30d</div>
          <div className="text-2xl font-bold font-mono tabular-nums text-slate-900 mt-1">
            {counts.expiring_soon}
          </div>
        </button>
      </div>

      {/* Filter Controls */}
      <section className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-5 space-y-4">
        <div>
          <h2 className="text-base font-bold text-slate-900">Threshold Warning Indicators</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Automated checks for expired supplies, upcoming 30-day expirations, critical stock gaps, and quantity anomalies.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-1.5">
          {(
            [
              { id: 'all', label: `All Warnings (${counts.all})` },
              { id: 'overdue', label: `Overdue (${counts.overdue})` },
              { id: 'critical_gap', label: `Critical Gaps (${counts.critical_gap})` },
              { id: 'expiring_soon', label: `Expiring ≤30d (${counts.expiring_soon})` },
              { id: 'anomaly', label: `Anomalies (${counts.anomaly})` },
            ] as const
          ).map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setFilterType(tab.id)}
              className={`min-h-[40px] px-3.5 py-2 text-xs font-semibold rounded-xl border transition-colors whitespace-nowrap shrink-0 ${
                filterType === tab.id
                  ? 'bg-slate-900 text-white border-slate-900'
                  : 'bg-white text-slate-700 border-slate-200 hover:border-slate-300'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </section>

      {filteredAlerts.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-2xl p-8 text-center">
          <CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto mb-2" aria-hidden="true" />
          <p className="text-base font-semibold text-slate-900">No active threshold warnings</p>
          <p className="text-sm text-slate-500 mt-1">
            All matching supplies are within target quantities and valid expiration dates.
          </p>
        </div>
      ) : (
        <div className="bg-white border border-slate-200 rounded-2xl divide-y divide-slate-100 overflow-hidden">
          {filteredAlerts.map((alert) => {
            const targetItem = itemsById.get(alert.itemId);
            const Icon =
              alert.severity === 'high'
                ? AlertCircle
                : alert.severity === 'medium'
                ? AlertTriangle
                : Info;
            const iconBox =
              alert.severity === 'high'
                ? 'bg-rose-50 text-rose-700 border-rose-200'
                : alert.severity === 'medium'
                ? 'bg-amber-50 text-amber-700 border-amber-200'
                : 'bg-slate-100 text-slate-700 border-slate-200';
            const labelTone =
              alert.severity === 'high'
                ? 'text-rose-700'
                : alert.severity === 'medium'
                ? 'text-amber-700'
                : 'text-slate-700';

            return (
              <div
                key={alert.id}
                className="p-4 sm:px-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-50/40 transition-colors"
              >
                <div className="flex items-start gap-3 min-w-0">
                  <div
                    className={`w-9 h-9 rounded-xl border flex items-center justify-center shrink-0 mt-0.5 ${iconBox}`}
                    aria-hidden="true"
                  >
                    <Icon className="w-4 h-4" />
                  </div>
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-baseline gap-x-2 gap-y-0.5">
                      <span className={`text-xs font-bold ${labelTone}`}>{alert.label}</span>
                      <span aria-hidden="true" className="text-slate-300">
                        ·
                      </span>
                      <span className="text-sm font-semibold text-slate-900">{alert.itemName}</span>
                      <span aria-hidden="true" className="text-slate-300">
                        ·
                      </span>
                      <span className="text-xs text-slate-500">{alert.category}</span>
                    </div>
                    <p className="text-xs text-slate-600 mt-1">{alert.detail}</p>
                  </div>
                </div>

                {targetItem && (
                  <button
                    type="button"
                    onClick={() => onEditItem(targetItem)}
                    className="min-h-[44px] px-4 py-2 text-xs font-semibold text-slate-700 border border-slate-300 hover:bg-slate-50 rounded-xl inline-flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0"
                  >
                    <Pencil className="w-3.5 h-3.5" aria-hidden="true" />
                    <span>Update Item</span>
                  </button>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
