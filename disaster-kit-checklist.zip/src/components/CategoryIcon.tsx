import React from 'react';
import {
  Droplets,
  FileLock2,
  Flashlight,
  HeartPulse,
  PackageCheck,
  Radio,
  Wrench,
} from 'lucide-react';
import { KitCategory } from '../types/checklist';

interface CategoryIconProps {
  category: KitCategory;
  completed?: boolean;
}

const CATEGORY_META: Record<
  KitCategory,
  { Icon: React.ComponentType<{ className?: string }>; tone: string }
> = {
  'Water & Food': {
    Icon: Droplets,
    tone: 'bg-sky-50 text-sky-700 border-sky-200/80',
  },
  'Medical & First Aid': {
    Icon: HeartPulse,
    tone: 'bg-rose-50 text-rose-700 border-rose-200/80',
  },
  'Power & Lighting': {
    Icon: Flashlight,
    tone: 'bg-amber-50 text-amber-700 border-amber-200/80',
  },
  'Tools & Shelter': {
    Icon: Wrench,
    tone: 'bg-slate-100 text-slate-700 border-slate-200',
  },
  'Documents & Cash': {
    Icon: FileLock2,
    tone: 'bg-indigo-50 text-indigo-700 border-indigo-200/80',
  },
  'Hygiene & Sanitation': {
    Icon: PackageCheck,
    tone: 'bg-teal-50 text-teal-700 border-teal-200/80',
  },
  Communication: {
    Icon: Radio,
    tone: 'bg-orange-50 text-orange-700 border-orange-200/80',
  },
};

export const CategoryIcon: React.FC<CategoryIconProps> = ({ category, completed }) => {
  const { Icon, tone } = CATEGORY_META[category];

  return (
    <div
      aria-hidden="true"
      className={`w-9 h-9 rounded-xl border flex items-center justify-center shrink-0 transition-colors ${
        completed ? 'bg-slate-100 text-slate-400 border-slate-200/70' : tone
      }`}
    >
      <Icon className="w-4 h-4" />
    </div>
  );
};
