import React, { useMemo, useState } from 'react';
import {
  CheckCircle2,
  Copy,
  Download,
  FileCode2,
  FileSpreadsheet,
  FileText,
  RefreshCw,
  ShieldAlert,
  Terminal,
  Upload,
  XCircle,
} from 'lucide-react';
import { ImportSummary, KitItem, SummaryMetrics, ThresholdAlert } from '../types/checklist';
import {
  exportAuditLogText,
  exportItemsToCsv,
  exportSummaryToMarkdown,
} from '../utils/analytics';
import { downloadTextFile } from '../utils/storage';
import { importDatasetText } from '../utils/validation';

interface DataExportViewProps {
  items: KitItem[];
  metrics: SummaryMetrics;
  alerts: ThresholdAlert[];
  onApplyImport: (importedItems: KitItem[], mode: 'merge' | 'replace') => void;
  onResetSeed: () => void;
  onTestCorruptRecovery: () => void;
}

type ExportFormat = 'csv' | 'json' | 'markdown' | 'txt';

const SAMPLE_IMPORT_CSV = `name,category,priority,targetQty,packedQty,unit,completed,expiryDate,location,notes
Portable Water Filter Straw,Water & Food,Critical,2,2,units,true,2029-05-01,Go-Bag Front Pocket,Filters 4000L
 ,Water & Food,Essential,3,1,packs,false,2027-01-01,Closet,Demonstrates blank name rejection
Invalid Qty Sample,Medical & First Aid,Critical,-10,5,boxes,false,2027-01-01,Medical Bin,Demonstrates negative target rejection
Solar Hand-Crank Lantern,Power & Lighting,Essential,2,1,units,false,,Garage Tote,Valid item with no expiry`;

export const DataExportView: React.FC<DataExportViewProps> = ({
  items,
  metrics,
  alerts,
  onApplyImport,
  onResetSeed,
  onTestCorruptRecovery,
}) => {
  const [previewFormat, setPreviewFormat] = useState<ExportFormat>('markdown');
  const [copiedFormat, setCopiedFormat] = useState<string | null>(null);

  const [importFormat, setImportFormat] = useState<'csv' | 'json'>('csv');
  const [importMode, setImportMode] = useState<'merge' | 'replace'>('merge');
  const [importText, setImportText] = useState('');
  const [importReport, setImportReport] = useState<ImportSummary | null>(null);

  const previewContent = useMemo(() => {
    if (previewFormat === 'json') return JSON.stringify(items, null, 2);
    if (previewFormat === 'csv') return exportItemsToCsv(items);
    if (previewFormat === 'markdown') return exportSummaryToMarkdown(items, metrics, alerts);
    return exportAuditLogText(items, metrics, alerts);
  }, [previewFormat, items, metrics, alerts]);

  const handleDownload = (format: ExportFormat) => {
    if (format === 'json') {
      downloadTextFile(
        'disaster-kit-checklist.json',
        JSON.stringify(items, null, 2),
        'application/json'
      );
    } else if (format === 'csv') {
      downloadTextFile(
        'disaster-kit-checklist.csv',
        exportItemsToCsv(items),
        'text/csv;charset=utf-8'
      );
    } else if (format === 'markdown') {
      downloadTextFile(
        'disaster-kit-summary.md',
        exportSummaryToMarkdown(items, metrics, alerts),
        'text/markdown;charset=utf-8'
      );
    } else {
      downloadTextFile(
        'disaster-kit-audit-log.txt',
        exportAuditLogText(items, metrics, alerts),
        'text/plain;charset=utf-8'
      );
    }
  };

  const handleCopyPreview = async () => {
    try {
      await navigator.clipboard.writeText(previewContent);
      setCopiedFormat(previewFormat);
      setTimeout(() => setCopiedFormat(null), 2000);
    } catch {
      // Clipboard fallback ignored if blocked in iframe
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const isJson = file.name.toLowerCase().endsWith('.json');
    setImportFormat(isJson ? 'json' : 'csv');

    const reader = new FileReader();
    reader.onload = () => {
      const content = typeof reader.result === 'string' ? reader.result : '';
      setImportText(content);
      const summary = importDatasetText(content, isJson ? 'json' : 'csv', items, importMode);
      setImportReport(summary);
    };
    reader.readAsText(file);
  };

  const handleValidateImport = () => {
    const summary = importDatasetText(importText, importFormat, items, importMode);
    setImportReport(summary);
  };

  const handleCommitImport = () => {
    if (!importReport || importReport.acceptedItems.length === 0) return;
    onApplyImport(importReport.acceptedItems, importMode);
    setImportText('');
    setImportReport(null);
  };

  const exportFormats = [
    { id: 'csv', title: 'Standard CSV', desc: 'Spreadsheet ready', Icon: FileSpreadsheet },
    { id: 'json', title: 'Structured JSON', desc: 'Full schema backup', Icon: FileCode2 },
    { id: 'markdown', title: 'Markdown Report', desc: 'Executive summary', Icon: FileText },
    { id: 'txt', title: 'Audit Log (.txt)', desc: 'Fixed-width report', Icon: Terminal },
  ] as const;

  return (
    <div className="space-y-5">
      {/* Multi-Format Export */}
      <section className="bg-white border border-slate-200 rounded-2xl p-5 space-y-4">
        <div>
          <h2 className="text-base font-bold text-slate-900">Multi-Format Export &amp; Reports</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Download or preview structured JSON, standardized CSV, Markdown summary, or plain-text audit logs.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {exportFormats.map(({ id, title, desc, Icon }) => (
            <button
              key={id}
              type="button"
              onClick={() => handleDownload(id)}
              className="min-h-[64px] p-3.5 text-left rounded-xl border border-slate-200 hover:border-slate-400 hover:bg-slate-50 active:scale-[0.99] transition-all flex items-center justify-between gap-3"
            >
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-9 h-9 rounded-xl bg-slate-100 border border-slate-200 flex items-center justify-center shrink-0 text-slate-700">
                  <Icon className="w-4 h-4" aria-hidden="true" />
                </div>
                <div className="min-w-0">
                  <div className="text-sm font-semibold text-slate-900 truncate">{title}</div>
                  <div className="text-xs text-slate-500 truncate">{desc}</div>
                </div>
              </div>
              <Download className="w-4 h-4 text-slate-500 shrink-0" aria-hidden="true" />
            </button>
          ))}
        </div>

        {/* Sleek Dark Slate Report Preview */}
        <div className="border border-slate-800 rounded-xl overflow-hidden bg-slate-950">
          <div className="flex flex-wrap items-center justify-between gap-2 px-3.5 py-2.5 bg-slate-900 border-b border-slate-800">
            <div className="inline-flex items-center gap-1">
              {(
                [
                  { id: 'markdown', label: 'Markdown' },
                  { id: 'txt', label: 'Audit Log' },
                  { id: 'csv', label: 'CSV' },
                  { id: 'json', label: 'JSON' },
                ] as const
              ).map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setPreviewFormat(tab.id)}
                  className={`min-h-[36px] px-3 py-1 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                    previewFormat === tab.id
                      ? 'bg-slate-800 text-white'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            <button
              type="button"
              onClick={handleCopyPreview}
              className="min-h-[36px] px-3 py-1 text-xs font-medium text-slate-200 hover:bg-slate-800 rounded-lg inline-flex items-center gap-1.5 whitespace-nowrap shrink-0"
            >
              <Copy className="w-3.5 h-3.5" aria-hidden="true" />
              <span>{copiedFormat === previewFormat ? 'Copied' : 'Copy'}</span>
            </button>
          </div>
          <pre className="p-4 text-xs font-mono text-slate-200 overflow-x-auto max-h-64 leading-relaxed">
            {previewContent}
          </pre>
        </div>
      </section>

      {/* Bulk Dataset Import with Row-by-Row Validation Log */}
      <section className="bg-white border border-slate-200 rounded-2xl p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-bold text-slate-900">Bulk Dataset Import</h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Upload a .csv / .json file or paste records below to run automatic row-by-row schema validation.
            </p>
          </div>

          <button
            type="button"
            onClick={() => {
              setImportFormat('csv');
              setImportText(SAMPLE_IMPORT_CSV);
              setImportReport(importDatasetText(SAMPLE_IMPORT_CSV, 'csv', items, importMode));
            }}
            className="min-h-[40px] px-3.5 py-2 text-xs font-semibold text-slate-700 border border-slate-300 hover:bg-slate-50 rounded-xl inline-flex items-center gap-1.5 whitespace-nowrap shrink-0"
          >
            <FileText className="w-3.5 h-3.5" aria-hidden="true" />
            <span>Load Mixed Test CSV</span>
          </button>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <label className="min-h-[44px] px-4 py-2 text-xs font-semibold text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-xl inline-flex items-center gap-2 cursor-pointer transition-colors">
            <Upload className="w-4 h-4" aria-hidden="true" />
            <span>Choose CSV or JSON File</span>
            <input
              type="file"
              accept=".csv,.json,text/csv,application/json"
              onChange={handleFileUpload}
              className="sr-only"
            />
          </label>

          <select
            aria-label="Import format"
            value={importFormat}
            onChange={(e) => setImportFormat(e.target.value as 'csv' | 'json')}
            className="min-h-[44px] px-3 py-2 text-xs font-medium rounded-xl border border-slate-300 bg-white text-slate-800"
          >
            <option value="csv">Format: CSV</option>
            <option value="json">Format: JSON</option>
          </select>

          <select
            aria-label="Import mode"
            value={importMode}
            onChange={(e) => setImportMode(e.target.value as 'merge' | 'replace')}
            className="min-h-[44px] px-3 py-2 text-xs font-medium rounded-xl border border-slate-300 bg-white text-slate-800"
          >
            <option value="merge">Append valid rows</option>
            <option value="replace">Replace current kit</option>
          </select>
        </div>

        <textarea
          rows={5}
          value={importText}
          onChange={(e) => setImportText(e.target.value)}
          placeholder="Paste CSV (name,category,priority,targetQty,packedQty,unit,completed,expiryDate,location,notes) or JSON array..."
          className="w-full p-3.5 text-xs font-mono rounded-xl border border-slate-300 bg-white text-slate-900 focus:outline-none focus:border-slate-900"
        />

        <div className="flex flex-wrap items-center justify-between gap-3">
          <button
            type="button"
            onClick={handleValidateImport}
            disabled={!importText.trim()}
            className="min-h-[44px] px-5 py-2.5 text-sm font-semibold text-white bg-slate-900 hover:bg-slate-800 disabled:opacity-40 rounded-xl transition-colors whitespace-nowrap shrink-0"
          >
            Validate Dataset
          </button>

          {importReport && importReport.acceptedCount > 0 && (
            <button
              type="button"
              onClick={handleCommitImport}
              className="min-h-[44px] px-5 py-2.5 text-sm font-semibold text-white bg-orange-600 hover:bg-orange-700 rounded-xl transition-colors whitespace-nowrap shrink-0"
            >
              Import {importReport.acceptedCount} Valid Row{importReport.acceptedCount === 1 ? '' : 's'}
            </button>
          )}
        </div>

        {importReport && (
          <div className="border border-slate-200 rounded-xl overflow-hidden">
            <div className="px-4 py-2.5 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-2 text-xs font-mono tabular-nums">
              <span className="font-semibold text-slate-900">
                Row-by-Row Validation Log ({importReport.totalRows} rows)
              </span>
              <div className="flex items-center gap-3">
                <span className="text-emerald-700 font-semibold">
                  {importReport.acceptedCount} accepted
                </span>
                <span className="text-rose-700 font-semibold">
                  {importReport.rejectedCount} rejected
                </span>
              </div>
            </div>

            <div className="divide-y divide-slate-100 max-h-60 overflow-y-auto">
              {importReport.logs.map((log, idx) => (
                <div
                  key={`${log.rowNumber}-${idx}`}
                  className="px-4 py-2.5 text-xs flex items-start gap-2.5"
                >
                  {log.status === 'accepted' ? (
                    <CheckCircle2
                      className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5"
                      aria-hidden="true"
                    />
                  ) : (
                    <XCircle
                      className="w-4 h-4 text-rose-600 shrink-0 mt-0.5"
                      aria-hidden="true"
                    />
                  )}
                  <div className="min-w-0">
                    <div className="font-semibold text-slate-900">
                      <span className="font-mono tabular-nums">Row {log.rowNumber}</span> ·{' '}
                      {log.rawName}
                    </div>
                    <p className={log.status === 'accepted' ? 'text-emerald-700' : 'text-rose-700'}>
                      {log.messages.join(' ')}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </section>

      {/* Local Storage Persistence & Recovery */}
      <section className="bg-white border border-slate-200 rounded-2xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-slate-900">Local Persistence &amp; Recovery</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Records auto-save offline in browser storage. Test recovery from corrupted files or restore the 36-item sample kit.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2.5 shrink-0">
          <button
            type="button"
            onClick={onTestCorruptRecovery}
            className="min-h-[44px] px-4 py-2 text-xs font-semibold text-amber-800 border border-amber-300 bg-amber-50 hover:bg-amber-100 rounded-xl inline-flex items-center gap-1.5 whitespace-nowrap shrink-0"
          >
            <ShieldAlert className="w-4 h-4" aria-hidden="true" />
            <span>Simulate Corrupt Recovery</span>
          </button>
          <button
            type="button"
            onClick={onResetSeed}
            className="min-h-[44px] px-4 py-2 text-xs font-semibold text-slate-700 border border-slate-300 hover:bg-slate-50 rounded-xl inline-flex items-center gap-1.5 whitespace-nowrap shrink-0"
          >
            <RefreshCw className="w-4 h-4" aria-hidden="true" />
            <span>Restore 36-Item Sample</span>
          </button>
        </div>
      </section>
    </div>
  );
};
