import React, { useMemo, useState } from 'react';
import {
  Activity,
  AlertCircle,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  CloudLightning,
  Filter,
  Flame,
  Radio,
  Waves,
  WifiOff,
  ZapOff,
} from 'lucide-react';
import {
  DISASTER_SCENARIOS,
  DisasterId,
  NO_SIGNAL_STEPS,
} from '../data/disasterScenarios';
import { KitItem } from '../types/checklist';

interface DisasterGuideCardProps {
  items: KitItem[];
  activeScenarioFilter: DisasterId | null;
  onApplyScenarioFilter: (scenarioId: DisasterId | null, matchedItemIds: string[]) => void;
}

const SCENARIO_ICONS: Record<DisasterId, React.ComponentType<{ className?: string }>> = {
  earthquake: Activity,
  flood: Waves,
  wildfire: Flame,
  blackout: ZapOff,
  storm: CloudLightning,
};

export const DisasterGuideCard: React.FC<DisasterGuideCardProps> = ({
  items,
  activeScenarioFilter,
  onApplyScenarioFilter,
}) => {
  const [selectedDisaster, setSelectedDisaster] = useState<DisasterId>('earthquake');
  const [panelMode, setPanelMode] = useState<'closed' | 'disaster' | 'nosignal'>('closed');

  const scenario = useMemo(
    () => DISASTER_SCENARIOS.find((s) => s.id === selectedDisaster) ?? DISASTER_SCENARIOS[0],
    [selectedDisaster]
  );

  const matchedKitItems = useMemo(() => {
    return items.filter((item) =>
      scenario.kitNameKeywords.some((kw) =>
        item.name.toLowerCase().includes(kw.toLowerCase())
      )
    );
  }, [items, scenario]);

  const matchedReadyCount = matchedKitItems.filter((i) => i.completed).length;

  const handleSelectDisaster = (id: DisasterId) => {
    setSelectedDisaster(id);
    setPanelMode('disaster');
  };

  const handleToggleNoSignal = () => {
    setPanelMode((prev) => (prev === 'nosignal' ? 'closed' : 'nosignal'));
  };

  const handleToggleExpand = () => {
    setPanelMode((prev) => (prev === 'closed' ? 'disaster' : 'closed'));
  };

  const isScenarioFilterActive = activeScenarioFilter === selectedDisaster;

  return (
    <section
      aria-label="Disaster Scenario & No-Signal Guide"
      className="bg-white border border-slate-200 rounded-2xl overflow-hidden"
    >
      {/* Compact Header & Quick Selectors */}
      <div className="p-4 sm:px-5 flex flex-col gap-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="min-w-0">
            <h2 className="text-sm sm:text-base font-bold text-slate-900">
              Disaster Response &amp; No-Signal Guide
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Select a disaster to see what kit to grab, or view offline steps if cell signal is lost.
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={handleToggleNoSignal}
              className={`min-h-[40px] px-3 py-1.5 text-xs font-semibold rounded-xl border inline-flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 ${
                panelMode === 'nosignal'
                  ? 'bg-slate-900 text-white border-slate-900'
                  : 'bg-amber-50 text-amber-900 border-amber-200 hover:bg-amber-100'
              }`}
            >
              <WifiOff className="w-3.5 h-3.5" aria-hidden="true" />
              <span>No Signal? What To Do</span>
            </button>

            <button
              type="button"
              onClick={handleToggleExpand}
              aria-expanded={panelMode !== 'closed'}
              aria-label={panelMode === 'closed' ? 'Expand disaster guide' : 'Collapse disaster guide'}
              className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 transition-colors"
            >
              {panelMode === 'closed' ? (
                <ChevronDown className="w-4 h-4" />
              ) : (
                <ChevronUp className="w-4 h-4" />
              )}
            </button>
          </div>
        </div>

        {/* Disaster Picker Row */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-0.5">
          {DISASTER_SCENARIOS.map((sc) => {
            const Icon = SCENARIO_ICONS[sc.id];
            const isSelected = panelMode === 'disaster' && selectedDisaster === sc.id;
            return (
              <button
                key={sc.id}
                type="button"
                onClick={() => handleSelectDisaster(sc.id)}
                className={`min-h-[40px] px-3 py-1.5 text-xs font-semibold rounded-xl border inline-flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 ${
                  isSelected
                    ? 'bg-orange-600 text-white border-orange-600'
                    : 'bg-white text-slate-700 border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                }`}
              >
                <Icon className="w-3.5 h-3.5" aria-hidden="true" />
                <span>{sc.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Expandable Content Panel */}
      {panelMode === 'disaster' && (
        <div className="border-t border-slate-200 bg-slate-50/70 p-4 sm:p-5 grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Left: Immediate Action & What To Take */}
          <div className="lg:col-span-5 space-y-3">
            <div className="bg-white border border-slate-200 rounded-xl p-4 space-y-2">
              <div className="text-xs font-semibold text-orange-700">
                Immediate {scenario.label} Action
              </div>
              <p className="text-xs sm:text-sm text-slate-700 leading-relaxed">
                {scenario.immediateAction}
              </p>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-4 space-y-2.5">
              <div className="text-xs font-semibold text-slate-900">
                Essential Go-Bag Checklist ({scenario.label})
              </div>
              <ul className="space-y-1.5 text-xs text-slate-700">
                {scenario.essentialTakeChecklist.map((entry, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <span className="font-mono tabular-nums text-slate-400 shrink-0">
                      0{idx + 1}.
                    </span>
                    <span>{entry}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Right: Matching Items From Your Kit */}
          <div className="lg:col-span-7 bg-white border border-slate-200 rounded-xl p-4 flex flex-col justify-between gap-4">
            <div>
              <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
                <div>
                  <h3 className="text-sm font-bold text-slate-900">
                    Kit Items to Grab ({matchedReadyCount}/{matchedKitItems.length} ready)
                  </h3>
                  <p className="text-xs text-slate-500">
                    Live status from your current disaster checklist
                  </p>
                </div>

                {matchedKitItems.length > 0 && (
                  <button
                    type="button"
                    onClick={() =>
                      onApplyScenarioFilter(
                        isScenarioFilterActive ? null : scenario.id,
                        isScenarioFilterActive ? [] : matchedKitItems.map((i) => i.id)
                      )
                    }
                    className={`min-h-[38px] px-3 py-1.5 text-xs font-semibold rounded-lg border inline-flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 ${
                      isScenarioFilterActive
                        ? 'bg-slate-900 text-white border-slate-900'
                        : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                    }`}
                  >
                    <Filter className="w-3.5 h-3.5" aria-hidden="true" />
                    <span>
                      {isScenarioFilterActive ? 'Clear Scenario Filter' : 'Filter Checklist Below'}
                    </span>
                  </button>
                )}
              </div>

              <div className="divide-y divide-slate-100">
                {matchedKitItems.map((item) => (
                  <div
                    key={item.id}
                    className="py-2.5 flex items-center justify-between gap-3 text-xs sm:text-sm"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      {item.completed ? (
                        <CheckCircle2
                          className="w-4 h-4 text-emerald-600 shrink-0"
                          aria-hidden="true"
                        />
                      ) : (
                        <AlertCircle
                          className="w-4 h-4 text-rose-600 shrink-0"
                          aria-hidden="true"
                        />
                      )}
                      <div className="min-w-0">
                        <div className="font-medium text-slate-900 truncate">{item.name}</div>
                        <div className="text-xs text-slate-500 truncate">{item.location}</div>
                      </div>
                    </div>

                    <div className="text-right font-mono tabular-nums text-xs shrink-0">
                      <span
                        className={
                          item.completed ? 'text-emerald-700 font-semibold' : 'text-rose-700 font-semibold'
                        }
                      >
                        {item.packedQty}/{item.targetQty} {item.unit}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2 text-xs text-slate-500">
              <span>Lost cell reception during {scenario.label.toLowerCase()}?</span>
              <button
                type="button"
                onClick={() => setPanelMode('nosignal')}
                className="font-semibold text-orange-700 hover:text-orange-800 whitespace-nowrap shrink-0"
              >
                Open No-Signal Guide →
              </button>
            </div>
          </div>
        </div>
      )}

      {panelMode === 'nosignal' && (
        <div className="border-t border-slate-200 bg-slate-900 text-white p-4 sm:p-5 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-amber-500/20 border border-amber-400/30 flex items-center justify-center shrink-0 text-amber-300">
                <Radio className="w-4 h-4" aria-hidden="true" />
              </div>
              <div>
                <h3 className="text-sm sm:text-base font-bold text-white">
                  No Cellular or Internet Signal — Action Protocol
                </h3>
                <p className="text-xs text-slate-300">
                  Follow these 5 offline communication steps and verify your backup gear status.
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setPanelMode('disaster')}
              className="min-h-[38px] px-3 py-1.5 text-xs font-semibold text-slate-200 border border-white/15 hover:bg-white/10 rounded-lg whitespace-nowrap shrink-0"
            >
              Back to Disaster Kits
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-3">
            {NO_SIGNAL_STEPS.map((step) => {
              const linkedItem = items.find((i) =>
                i.name.toLowerCase().includes(step.relatedItemKeyword.toLowerCase())
              );

              return (
                <div
                  key={step.stepNumber}
                  className="bg-white/5 border border-white/10 rounded-xl p-3.5 flex flex-col justify-between gap-3"
                >
                  <div>
                    <div className="text-xs font-mono tabular-nums font-semibold text-orange-400">
                      {step.stepNumber}.
                    </div>
                    <h4 className="text-xs sm:text-sm font-semibold text-white mt-1 leading-snug">
                      {step.title}
                    </h4>
                    <p className="text-xs text-slate-300 mt-1.5 leading-relaxed">{step.action}</p>
                  </div>

                  {linkedItem && (
                    <div className="pt-2.5 border-t border-white/10 flex items-center justify-between gap-2 text-[11px]">
                      <span className="text-slate-400 truncate">{linkedItem.name}</span>
                      <span
                        className={`font-semibold shrink-0 ${
                          linkedItem.completed ? 'text-emerald-400' : 'text-rose-400'
                        }`}
                      >
                        {linkedItem.completed ? 'Packed' : 'Missing'}
                      </span>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}
    </section>
  );
};
