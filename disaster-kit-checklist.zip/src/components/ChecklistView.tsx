import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  Check,
  ChevronLeft,
  ChevronRight,
  Minus,
  Pencil,
  Plus,
  Search,
  ShieldCheck,
  Trash2,
  X,
} from 'lucide-react';
import { DisasterId } from '../data/disasterScenarios';
import {
  KIT_CATEGORIES,
  KIT_PRIORITIES,
  KitCategory,
  KitItem,
  KitPriority,
  ThresholdAlert,
} from '../types/checklist';
import { computeItemReadiness } from '../utils/analytics';
import { CategoryIcon } from './CategoryIcon';
import { DisasterGuideCard } from './DisasterGuideCard';

interface ChecklistViewProps {
  items: KitItem[];
  alerts: ThresholdAlert[];
  onToggleComplete: (id: string) => void;
  onAdjustPacked: (id: string, delta: number) => void;
  onEditItem: (item: KitItem) => void;
  onDeleteItem: (id: string) => void;
  onAddNew: () => void;
}

type StatusFilter = 'all' | 'incomplete' | 'completed' | 'flagged';
type SortOption = 'urgency' | 'name' | 'category' | 'readiness';

const PAGE_SIZE_OPTIONS = [10, 20, 50] as const;

export const ChecklistView: React.FC<ChecklistViewProps> = ({
  items,
  alerts,
  onToggleComplete,
  onAdjustPacked,
  onEditItem,
  onDeleteItem,
  onAddNew,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<KitCategory | 'All'>('All');
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('all');
  const [priorityFilter, setPriorityFilter] = useState<KitPriority | 'All'>('All');
  const [sortBy, setSortBy] = useState<SortOption>('urgency');
  const [pageSize, setPageSize] = useState<number>(10);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [heroImgFailed, setHeroImgFailed] = useState(false);
  const [activeScenarioFilter, setActiveScenarioFilter] = useState<DisasterId | null>(null);
  const [scenarioItemIds, setScenarioItemIds] = useState<string[]>([]);

  const alertsByItemId = useMemo(() => {
    const map = new Map<string, ThresholdAlert[]>();
    for (const alert of alerts) {
      const existing = map.get(alert.itemId) ?? [];
      existing.push(alert);
      map.set(alert.itemId, existing);
    }
    return map;
  }, [alerts]);

  const filteredItems = useMemo(() => {
    const query = searchQuery.trim().toLowerCase();
    const priorityRank: Record<KitPriority, number> = {
      Critical: 0,
      Essential: 1,
      Recommended: 2,
    };

    const filtered = items.filter((item) => {
      if (activeScenarioFilter && !scenarioItemIds.includes(item.id)) return false;
      if (selectedCategory !== 'All' && item.category !== selectedCategory) return false;
      if (priorityFilter !== 'All' && item.priority !== priorityFilter) return false;
      if (statusFilter === 'completed' && !item.completed) return false;
      if (statusFilter === 'incomplete' && item.completed) return false;
      if (statusFilter === 'flagged' && !alertsByItemId.has(item.id)) return false;

      if (query) {
        const haystack =
          `${item.name} ${item.category} ${item.location} ${item.notes} ${item.unit}`.toLowerCase();
        if (!haystack.includes(query)) return false;
      }
      return true;
    });

    return filtered.sort((a, b) => {
      if (sortBy === 'name') return a.name.localeCompare(b.name);
      if (sortBy === 'category')
        return a.category.localeCompare(b.category) || a.name.localeCompare(b.name);
      if (sortBy === 'readiness') return computeItemReadiness(a) - computeItemReadiness(b);
      const aAlerts = alertsByItemId.get(a.id)?.length ?? 0;
      const bAlerts = alertsByItemId.get(b.id)?.length ?? 0;
      if (a.completed !== b.completed) return a.completed ? 1 : -1;
      if (aAlerts !== bAlerts) return bAlerts - aAlerts;
      return priorityRank[a.priority] - priorityRank[b.priority];
    });
  }, [
    items,
    activeScenarioFilter,
    scenarioItemIds,
    searchQuery,
    selectedCategory,
    statusFilter,
    priorityFilter,
    sortBy,
    alertsByItemId,
  ]);

  const totalPages = Math.max(1, Math.ceil(filteredItems.length / pageSize));
  const safePage = Math.min(currentPage, totalPages);
  const paginatedItems = useMemo(() => {
    const start = (safePage - 1) * pageSize;
    return filteredItems.slice(start, start + pageSize);
  }, [filteredItems, safePage, pageSize]);

  const resetFilters = () => {
    setSearchQuery('');
    setSelectedCategory('All');
    setStatusFilter('all');
    setPriorityFilter('All');
    setActiveScenarioFilter(null);
    setScenarioItemIds([]);
    setCurrentPage(1);
  };

  const handleApplyScenarioFilter = (scenarioId: DisasterId | null, matchedIds: string[]) => {
    setActiveScenarioFilter(scenarioId);
    setScenarioItemIds(matchedIds);
    setCurrentPage(1);
  };

  const completedCount = items.filter((i) => i.completed).length;
  const criticalItems = items.filter((i) => i.priority === 'Critical');
  const criticalReady = criticalItems.filter((i) => i.completed).length;
  const readinessPct = items.length > 0 ? Math.round((completedCount / items.length) * 100) : 0;

  const ringRadius = 34;
  const ringCircumference = 2 * Math.PI * ringRadius;
  const ringOffset = ringCircumference - (readinessPct / 100) * ringCircumference;

  return (
    <div className="space-y-5">
      {/* Hero Readiness Command Card */}
      <section className="grid grid-cols-1 lg:grid-cols-12 rounded-2xl overflow-hidden border border-slate-200 bg-slate-900 text-white shadow-xs items-stretch">
        <div className="lg:col-span-7 p-5 sm:p-6 flex flex-col justify-between gap-5">
          <div className="flex items-start justify-between gap-4">
            <div className="min-w-0">
              <p className="text-xs font-medium text-slate-300">
                72-Hour Household Emergency Inventory
              </p>
              <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white mt-1 text-balance">
                Disaster Kit Readiness
              </h1>
              <p className="text-xs sm:text-sm text-slate-300 mt-1.5 max-w-lg leading-relaxed">
                Track essential supplies, verify expiration dates, and close critical stock gaps offline.
              </p>
            </div>

            <div className="relative w-20 h-20 sm:w-24 sm:h-24 shrink-0 flex items-center justify-center">
              <svg
                className="w-full h-full -rotate-90"
                viewBox="0 0 84 84"
                aria-hidden="true"
              >
                <circle
                  cx="42"
                  cy="42"
                  r={ringRadius}
                  fill="none"
                  stroke="rgba(255,255,255,0.14)"
                  strokeWidth="8"
                />
                <circle
                  cx="42"
                  cy="42"
                  r={ringRadius}
                  fill="none"
                  stroke="#F97316"
                  strokeWidth="8"
                  strokeLinecap="round"
                  strokeDasharray={ringCircumference}
                  strokeDashoffset={ringOffset}
                  className="transition-all duration-300"
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-lg sm:text-xl font-bold font-mono tabular-nums text-white">
                  {readinessPct}%
                </span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3 pt-4 border-t border-white/10">
            <div>
              <p className="text-[11px] text-slate-400">Packed Items</p>
              <p className="text-base sm:text-lg font-bold font-mono tabular-nums text-white mt-0.5">
                {completedCount}/{items.length}
              </p>
            </div>
            <div>
              <p className="text-[11px] text-slate-400">Critical Tier</p>
              <p className="text-base sm:text-lg font-bold font-mono tabular-nums text-white mt-0.5">
                {criticalReady}/{criticalItems.length}
              </p>
            </div>
            <div>
              <p className="text-[11px] text-slate-400">Needs Attention</p>
              <p className="text-base sm:text-lg font-bold font-mono tabular-nums text-orange-400 mt-0.5">
                {alertsByItemId.size} items
              </p>
            </div>
          </div>
        </div>

        {/* Studio Kit Photography Column */}
        <div className="lg:col-span-5 relative min-h-[156px] lg:min-h-full bg-slate-800 overflow-hidden">
          {!heroImgFailed ? (
            <img
              src="/src/assets/images/disaster_kit_hero_1795525863370.jpg"
              alt="Organized disaster preparedness kit with go-bag, water canteen, first-aid pouch, flashlight, and weather radio"
              referrerPolicy="no-referrer"
              onError={() => setHeroImgFailed(true)}
              className="w-full h-40 lg:h-full object-cover object-center"
            />
          ) : (
            <div className="w-full h-40 lg:h-full bg-gradient-to-br from-slate-800 via-slate-800 to-slate-900 flex flex-col items-center justify-center p-6 text-center">
              <ShieldCheck className="w-9 h-9 text-orange-400 mb-2" aria-hidden="true" />
              <span className="text-xs font-medium text-slate-300">
                Preparedness Kit Inventory
              </span>
            </div>
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/75 via-slate-950/15 to-transparent pointer-events-none" />
          <div className="absolute bottom-3 left-4 right-4 flex items-center justify-between gap-2 text-xs text-white/95">
            <span className="font-medium truncate">Go-Bag &amp; Home Reserve</span>
            <button
              type="button"
              onClick={() => {
                setStatusFilter('flagged');
                setCurrentPage(1);
              }}
              className="px-2.5 py-1 rounded-lg bg-white/15 hover:bg-white/25 backdrop-blur-xs text-white font-medium transition-colors whitespace-nowrap shrink-0"
            >
              Filter Flagged
            </button>
          </div>
        </div>
      </section>

      {/* Disaster Scenario & No-Signal Guide */}
      <DisasterGuideCard
        items={items}
        activeScenarioFilter={activeScenarioFilter}
        onApplyScenarioFilter={handleApplyScenarioFilter}
      />

      {/* Search & Filter Toolbar */}
      <section className="bg-white border border-slate-200 rounded-2xl p-4 space-y-3.5">
        <div className="flex flex-col lg:flex-row gap-3">
          <div className="relative flex-1">
            <Search
              className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none"
              aria-hidden="true"
            />
            <input
              type="search"
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setCurrentPage(1);
              }}
              placeholder="Search items, locations, notes, or units..."
              aria-label="Search checklist records"
              className="w-full min-h-[44px] pl-10 pr-9 py-2 text-sm rounded-xl border border-slate-300 bg-white text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-slate-900 focus:ring-2 focus:ring-slate-200"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => {
                  setSearchQuery('');
                  setCurrentPage(1);
                }}
                aria-label="Clear search"
                className="min-h-[44px] min-w-[44px] flex items-center justify-center absolute right-0 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          <div className="grid grid-cols-2 sm:flex items-center gap-2.5">
            <select
              aria-label="Filter by priority"
              value={priorityFilter}
              onChange={(e) => {
                setPriorityFilter(e.target.value as KitPriority | 'All');
                setCurrentPage(1);
              }}
              className="min-h-[44px] px-3 py-2 text-xs sm:text-sm font-medium rounded-xl border border-slate-300 bg-white text-slate-800 focus:outline-none focus:border-slate-900"
            >
              <option value="All">All Priorities</option>
              {KIT_PRIORITIES.map((p) => (
                <option key={p} value={p}>
                  {p}
                </option>
              ))}
            </select>

            <select
              aria-label="Sort items"
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as SortOption)}
              className="min-h-[44px] px-3 py-2 text-xs sm:text-sm font-medium rounded-xl border border-slate-300 bg-white text-slate-800 focus:outline-none focus:border-slate-900"
            >
              <option value="urgency">Sort: Urgency</option>
              <option value="category">Sort: Category</option>
              <option value="name">Sort: Name (A–Z)</option>
              <option value="readiness">Sort: Readiness %</option>
            </select>
          </div>
        </div>

        {/* Status Segmented Filter */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="inline-flex items-center gap-1 p-1 bg-slate-100 rounded-xl overflow-x-auto max-w-full">
            {(
              [
                { id: 'all', label: 'All' },
                { id: 'incomplete', label: 'Remaining' },
                { id: 'completed', label: 'Packed' },
                { id: 'flagged', label: `Flagged (${alertsByItemId.size})` },
              ] as const
            ).map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => {
                  setStatusFilter(tab.id);
                  setCurrentPage(1);
                }}
                className={`min-h-[36px] px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                  statusFilter === tab.id
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <span className="text-xs text-slate-500 font-mono tabular-nums">
            Showing {filteredItems.length} of {items.length} records
          </span>
        </div>

        {/* Category Filter Buttons */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
          <button
            type="button"
            onClick={() => {
              setSelectedCategory('All');
              setCurrentPage(1);
            }}
            className={`min-h-[38px] px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors whitespace-nowrap shrink-0 ${
              selectedCategory === 'All'
                ? 'bg-slate-900 text-white border-slate-900'
                : 'bg-white text-slate-700 border-slate-200 hover:border-slate-300'
            }`}
          >
            All Categories
          </button>
          {KIT_CATEGORIES.map((category) => (
            <button
              key={category}
              type="button"
              onClick={() => {
                setSelectedCategory(category);
                setCurrentPage(1);
              }}
              className={`min-h-[38px] px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors whitespace-nowrap shrink-0 ${
                selectedCategory === category
                  ? 'bg-slate-900 text-white border-slate-900'
                  : 'bg-white text-slate-700 border-slate-200 hover:border-slate-300'
              }`}
            >
              {category}
            </button>
          ))}
        </div>
      </section>

      {/* Checklist Items */}
      {paginatedItems.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-2xl p-8 text-center">
          <p className="text-base font-semibold text-slate-900">No matching checklist items</p>
          <p className="text-sm text-slate-500 mt-1">
            Adjust your search keywords or filters, or add a new item to your preparedness kit.
          </p>
          <div className="mt-4 flex items-center justify-center gap-3">
            <button
              type="button"
              onClick={resetFilters}
              className="min-h-[44px] px-4 py-2 text-sm font-medium text-slate-700 border border-slate-300 rounded-xl hover:bg-slate-50 whitespace-nowrap shrink-0"
            >
              Reset Filters
            </button>
            <button
              type="button"
              onClick={onAddNew}
              className="min-h-[44px] px-4 py-2 text-sm font-semibold text-white bg-orange-600 hover:bg-orange-700 rounded-xl whitespace-nowrap shrink-0"
            >
              Add Kit Item
            </button>
          </div>
        </div>
      ) : (
        <div className="bg-white border border-slate-200 rounded-2xl divide-y divide-slate-100 overflow-hidden">
          {paginatedItems.map((item) => {
            const itemAlerts = alertsByItemId.get(item.id) ?? [];
            const readiness = computeItemReadiness(item);
            const isDeleting = confirmDeleteId === item.id;

            return (
              <article
                key={item.id}
                className={`p-4 sm:px-5 sm:py-4 transition-colors ${
                  item.completed ? 'bg-slate-50/60' : 'bg-white hover:bg-slate-50/40'
                }`}
              >
                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3.5">
                  {/* Left: Checkbox + Category Icon + Content */}
                  <div className="flex items-start gap-3 min-w-0 flex-1">
                    <button
                      type="button"
                      onClick={() => onToggleComplete(item.id)}
                      aria-label={
                        item.completed
                          ? `Mark ${item.name} as incomplete`
                          : `Mark ${item.name} as packed`
                      }
                      className="min-h-[44px] min-w-[44px] -ml-1.5 flex items-center justify-center rounded-xl shrink-0 active:scale-95 transition-transform"
                    >
                      <span
                        className={`w-6 h-6 rounded-lg border flex items-center justify-center transition-colors ${
                          item.completed
                            ? 'bg-emerald-600 border-emerald-600 text-white'
                            : 'bg-white border-slate-300 text-transparent hover:border-slate-500'
                        }`}
                      >
                        <Check className="w-4 h-4 stroke-[2.5]" />
                      </span>
                    </button>

                    <div className="hidden sm:block mt-0.5">
                      <CategoryIcon category={item.category} completed={item.completed} />
                    </div>

                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-baseline gap-x-2.5 gap-y-0.5">
                        <h3
                          className={`text-sm sm:text-base font-semibold leading-snug ${
                            item.completed ? 'text-slate-500 line-through' : 'text-slate-900'
                          }`}
                        >
                          {item.name}
                        </h3>
                        <span
                          className={`text-xs font-semibold ${
                            item.priority === 'Critical'
                              ? 'text-rose-700'
                              : item.priority === 'Essential'
                              ? 'text-slate-700'
                              : 'text-slate-500'
                          }`}
                        >
                          {item.priority}
                        </span>
                      </div>

                      <div className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs text-slate-500">
                        <span>{item.category}</span>
                        <span aria-hidden="true">·</span>
                        <span>{item.location}</span>
                        <span aria-hidden="true">·</span>
                        <span className="font-mono tabular-nums">
                          {item.expiryDate ? `Exp ${item.expiryDate}` : 'No expiry'}
                        </span>
                      </div>

                      {item.notes && (
                        <p className="mt-1.5 text-xs text-slate-600 leading-relaxed line-clamp-2">
                          {item.notes}
                        </p>
                      )}

                      {itemAlerts.length > 0 && (
                        <div className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1">
                          {itemAlerts.map((alert) => (
                            <span
                              key={alert.id}
                              className={`inline-flex items-center gap-1 text-xs font-medium ${
                                alert.severity === 'high'
                                  ? 'text-rose-700'
                                  : alert.severity === 'medium'
                                  ? 'text-amber-700'
                                  : 'text-slate-700'
                              }`}
                            >
                              <AlertTriangle className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                              <span>
                                {alert.label}: {alert.detail}
                              </span>
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Right: Quantity Stepper with Micro Bar & Actions */}
                  <div className="flex items-center justify-between lg:justify-end gap-3 pl-11 lg:pl-0 shrink-0">
                    <div className="flex flex-col gap-1">
                      <div className="flex items-center gap-1 border border-slate-200 rounded-xl bg-white p-0.5">
                        <button
                          type="button"
                          onClick={() => onAdjustPacked(item.id, -1)}
                          disabled={item.packedQty <= 0}
                          aria-label={`Decrease packed quantity for ${item.name}`}
                          className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-lg text-slate-700 hover:bg-slate-100 active:scale-95 disabled:opacity-35 disabled:pointer-events-none transition-all"
                        >
                          <Minus className="w-4 h-4" />
                        </button>
                        <div className="px-2 text-center min-w-[84px]">
                          <div className="text-xs sm:text-sm font-mono tabular-nums font-semibold text-slate-900">
                            {item.packedQty}/{item.targetQty}
                          </div>
                          <div className="text-[11px] text-slate-500 truncate max-w-[84px]">
                            {item.unit} ({readiness}%)
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => onAdjustPacked(item.id, 1)}
                          disabled={item.packedQty >= 999}
                          aria-label={`Increase packed quantity for ${item.name}`}
                          className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-lg text-slate-700 hover:bg-slate-100 active:scale-95 disabled:opacity-35 disabled:pointer-events-none transition-all"
                        >
                          <Plus className="w-4 h-4" />
                        </button>
                      </div>
                      <div className="h-1 w-full bg-slate-100 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full transition-all duration-200 ${
                            readiness === 100
                              ? 'bg-emerald-600'
                              : readiness >= 50
                              ? 'bg-orange-500'
                              : 'bg-rose-500'
                          }`}
                          style={{ width: `${readiness}%` }}
                        />
                      </div>
                    </div>

                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => onEditItem(item)}
                        aria-label={`Edit ${item.name}`}
                        className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors"
                      >
                        <Pencil className="w-4 h-4" />
                      </button>

                      {isDeleting ? (
                        <div className="flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => {
                              onDeleteItem(item.id);
                              setConfirmDeleteId(null);
                            }}
                            className="min-h-[44px] px-3 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-700 rounded-xl whitespace-nowrap shrink-0"
                          >
                            Delete
                          </button>
                          <button
                            type="button"
                            onClick={() => setConfirmDeleteId(null)}
                            className="min-h-[44px] px-2.5 text-xs font-medium text-slate-600 hover:bg-slate-100 rounded-xl whitespace-nowrap shrink-0"
                          >
                            Cancel
                          </button>
                        </div>
                      ) : (
                        <button
                          type="button"
                          onClick={() => setConfirmDeleteId(item.id)}
                          aria-label={`Delete ${item.name}`}
                          className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl text-slate-500 hover:text-rose-700 hover:bg-rose-50 transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      )}

      {/* Pagination Footer */}
      {filteredItems.length > 0 && (
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-white border border-slate-200 rounded-2xl px-4 py-3">
          <div className="flex items-center gap-2 text-xs text-slate-600">
            <span>Rows per page:</span>
            <select
              aria-label="Items per page"
              value={pageSize}
              onChange={(e) => {
                setPageSize(Number(e.target.value));
                setCurrentPage(1);
              }}
              className="min-h-[38px] px-2.5 py-1 rounded-lg border border-slate-300 bg-white font-mono tabular-nums text-slate-800"
            >
              {PAGE_SIZE_OPTIONS.map((size) => (
                <option key={size} value={size}>
                  {size}
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs font-mono tabular-nums text-slate-600 mr-2">
              Page {safePage} of {totalPages}
            </span>
            <button
              type="button"
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              disabled={safePage <= 1}
              aria-label="Previous page"
              className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl border border-slate-200 text-slate-700 hover:bg-slate-50 disabled:opacity-40 disabled:pointer-events-none"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              disabled={safePage >= totalPages}
              aria-label="Next page"
              className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl border border-slate-200 text-slate-700 hover:bg-slate-50 disabled:opacity-40 disabled:pointer-events-none"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
