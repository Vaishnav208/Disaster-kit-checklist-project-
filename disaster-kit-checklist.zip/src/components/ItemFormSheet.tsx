import React, { useEffect, useState } from 'react';
import { AlertCircle, CheckCircle2, FlaskConical, X } from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import {
  KIT_CATEGORIES,
  KIT_PRIORITIES,
  KitItem,
  KitItemDraft,
  ValidationErrors,
} from '../types/checklist';
import { validateKitItemDraft } from '../utils/validation';

interface ItemFormSheetProps {
  isOpen: boolean;
  editingItem: KitItem | null;
  existingItems: KitItem[];
  onClose: () => void;
  onSave: (draft: Omit<KitItem, 'id' | 'updatedAt'>, editingId?: string) => void;
}

const EMPTY_DRAFT: KitItemDraft = {
  name: '',
  category: 'Water & Food',
  priority: 'Essential',
  targetQty: 1,
  packedQty: 0,
  unit: 'units',
  completed: false,
  expiryDate: '',
  location: '',
  notes: '',
};

export const ItemFormSheet: React.FC<ItemFormSheetProps> = ({
  isOpen,
  editingItem,
  existingItems,
  onClose,
  onSave,
}) => {
  const [draft, setDraft] = useState<KitItemDraft>(EMPTY_DRAFT);
  const [errors, setErrors] = useState<ValidationErrors>({});
  const [hasSubmitted, setHasSubmitted] = useState(false);

  useEffect(() => {
    if (!isOpen) return;
    if (editingItem) {
      setDraft({
        name: editingItem.name,
        category: editingItem.category,
        priority: editingItem.priority,
        targetQty: editingItem.targetQty,
        packedQty: editingItem.packedQty,
        unit: editingItem.unit,
        completed: editingItem.completed,
        expiryDate: editingItem.expiryDate,
        location: editingItem.location,
        notes: editingItem.notes,
      });
    } else {
      setDraft(EMPTY_DRAFT);
    }
    setErrors({});
    setHasSubmitted(false);
  }, [isOpen, editingItem]);

  const runLiveValidation = (nextDraft: KitItemDraft) => {
    if (!hasSubmitted) return;
    const check = validateKitItemDraft(nextDraft, existingItems, editingItem?.id);
    setErrors(check.errors);
  };

  const updateField = <K extends keyof KitItemDraft>(field: K, value: KitItemDraft[K]) => {
    const next = { ...draft, [field]: value };
    setDraft(next);
    runLiveValidation(next);
  };

  const handleLoadInvalidExample = () => {
    const badDraft: KitItemDraft = {
      name: ' ',
      category: 'Invalid Category',
      priority: 'Essential',
      targetQty: -5,
      packedQty: 1200,
      unit: 'units@bad!',
      completed: false,
      expiryDate: '2018-02-30',
      location: 'A',
      notes: '',
    };
    setDraft(badDraft);
    setHasSubmitted(true);
    const check = validateKitItemDraft(badDraft, existingItems, editingItem?.id);
    setErrors(check.errors);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setHasSubmitted(true);
    const result = validateKitItemDraft(draft, existingItems, editingItem?.id);
    if (!result.isValid || !result.sanitized) {
      setErrors(result.errors);
      return;
    }
    onSave(result.sanitized, editingItem?.id);
    onClose();
  };

  const errorCount = Object.keys(errors).length;

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.16, ease: [0.16, 1, 0.3, 1] }}
          className="fixed inset-0 z-50 flex items-end lg:items-center justify-center bg-slate-950/50 backdrop-blur-xs"
          role="dialog"
          aria-modal="true"
          aria-labelledby="item-sheet-title"
        >
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
            className="w-full lg:max-w-2xl bg-white rounded-t-3xl lg:rounded-2xl shadow-xl border border-slate-200 max-h-[92vh] flex flex-col overflow-hidden"
          >
            <div className="lg:hidden w-10 h-1.5 bg-slate-300 rounded-full mx-auto mt-3 mb-1 shrink-0" />



        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200 shrink-0">
          <div>
            <h2 id="item-sheet-title" className="text-lg font-bold text-slate-900">
              {editingItem ? 'Edit Kit Item' : 'Add Disaster Kit Item'}
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              All fields are sanitized and validated against preparedness rules.
            </p>
          </div>
          <div className="flex items-center gap-2">
            {!editingItem && (
              <button
                type="button"
                onClick={handleLoadInvalidExample}
                className="min-h-[44px] px-3 text-xs font-medium text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg inline-flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0"
                title="Populate erroneous inputs to test defensive validation"
              >
                <FlaskConical className="w-3.5 h-3.5" aria-hidden="true" />
                <span>Test Validation</span>
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              aria-label="Close form"
              className="min-h-[44px] min-w-[44px] flex items-center justify-center text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        <form onSubmit={handleSubmit} noValidate className="flex-1 overflow-y-auto px-5 py-4 space-y-4">
          {hasSubmitted && errorCount > 0 && (
            <div
              role="alert"
              className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-900 text-sm flex items-start gap-2.5"
            >
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" aria-hidden="true" />
              <div>
                <p className="font-semibold">
                  {errorCount} validation {errorCount === 1 ? 'error' : 'errors'} blocked submission
                </p>
                <p className="text-xs text-rose-700 mt-0.5">
                  Correct the highlighted fields below before saving to local storage.
                </p>
              </div>
            </div>
          )}

          <div>
            <label htmlFor="field-name" className="block text-xs font-semibold text-slate-700 mb-1.5">
              Item Name <span className="text-rose-600">*</span>
            </label>
            <input
              id="field-name"
              type="text"
              value={draft.name}
              onChange={(e) => updateField('name', e.target.value)}
              placeholder="e.g., Potable Drinking Water (4L Jugs)"
              className={`w-full min-h-[44px] px-3.5 py-2 text-sm rounded-xl border bg-white text-slate-900 focus:outline-none focus:ring-2 ${
                errors.name
                  ? 'border-rose-400 focus:ring-rose-200'
                  : 'border-slate-300 focus:border-slate-900 focus:ring-slate-200'
              }`}
            />
            {errors.name && <p className="mt-1 text-xs text-rose-600">{errors.name}</p>}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="field-category" className="block text-xs font-semibold text-slate-700 mb-1.5">
                Category <span className="text-rose-600">*</span>
              </label>
              <select
                id="field-category"
                value={draft.category}
                onChange={(e) => updateField('category', e.target.value)}
                className={`w-full min-h-[44px] px-3 py-2 text-sm rounded-xl border bg-white text-slate-900 focus:outline-none focus:ring-2 ${
                  errors.category
                    ? 'border-rose-400 focus:ring-rose-200'
                    : 'border-slate-300 focus:border-slate-900 focus:ring-slate-200'
                }`}
              >
                {KIT_CATEGORIES.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
                {!KIT_CATEGORIES.includes(draft.category as (typeof KIT_CATEGORIES)[number]) && (
                  <option value={draft.category}>{draft.category} (Invalid)</option>
                )}
              </select>
              {errors.category && <p className="mt-1 text-xs text-rose-600">{errors.category}</p>}
            </div>

            <div>
              <label htmlFor="field-priority" className="block text-xs font-semibold text-slate-700 mb-1.5">
                Priority Level <span className="text-rose-600">*</span>
              </label>
              <select
                id="field-priority"
                value={draft.priority}
                onChange={(e) => updateField('priority', e.target.value)}
                className={`w-full min-h-[44px] px-3 py-2 text-sm rounded-xl border bg-white text-slate-900 focus:outline-none focus:ring-2 ${
                  errors.priority
                    ? 'border-rose-400 focus:ring-rose-200'
                    : 'border-slate-300 focus:border-slate-900 focus:ring-slate-200'
                }`}
              >
                {KIT_PRIORITIES.map((p) => (
                  <option key={p} value={p}>
                    {p}
                  </option>
                ))}
              </select>
              {errors.priority && <p className="mt-1 text-xs text-rose-600">{errors.priority}</p>}
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label htmlFor="field-packed" className="block text-xs font-semibold text-slate-700 mb-1.5">
                Packed Qty
              </label>
              <input
                id="field-packed"
                type="number"
                inputMode="numeric"
                value={draft.packedQty}
                onChange={(e) => updateField('packedQty', e.target.value)}
                className={`w-full min-h-[44px] px-3 py-2 text-sm font-mono tabular-nums rounded-xl border bg-white text-slate-900 focus:outline-none focus:ring-2 ${
                  errors.packedQty
                    ? 'border-rose-400 focus:ring-rose-200'
                    : 'border-slate-300 focus:border-slate-900 focus:ring-slate-200'
                }`}
              />
              {errors.packedQty && <p className="mt-1 text-xs text-rose-600">{errors.packedQty}</p>}
            </div>

            <div>
              <label htmlFor="field-target" className="block text-xs font-semibold text-slate-700 mb-1.5">
                Target Qty <span className="text-rose-600">*</span>
              </label>
              <input
                id="field-target"
                type="number"
                inputMode="numeric"
                value={draft.targetQty}
                onChange={(e) => updateField('targetQty', e.target.value)}
                className={`w-full min-h-[44px] px-3 py-2 text-sm font-mono tabular-nums rounded-xl border bg-white text-slate-900 focus:outline-none focus:ring-2 ${
                  errors.targetQty
                    ? 'border-rose-400 focus:ring-rose-200'
                    : 'border-slate-300 focus:border-slate-900 focus:ring-slate-200'
                }`}
              />
              {errors.targetQty && <p className="mt-1 text-xs text-rose-600">{errors.targetQty}</p>}
            </div>

            <div>
              <label htmlFor="field-unit" className="block text-xs font-semibold text-slate-700 mb-1.5">
                Unit <span className="text-rose-600">*</span>
              </label>
              <input
                id="field-unit"
                type="text"
                value={draft.unit}
                onChange={(e) => updateField('unit', e.target.value)}
                placeholder="liters"
                className={`w-full min-h-[44px] px-3 py-2 text-sm rounded-xl border bg-white text-slate-900 focus:outline-none focus:ring-2 ${
                  errors.unit
                    ? 'border-rose-400 focus:ring-rose-200'
                    : 'border-slate-300 focus:border-slate-900 focus:ring-slate-200'
                }`}
              />
              {errors.unit && <p className="mt-1 text-xs text-rose-600">{errors.unit}</p>}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="field-location" className="block text-xs font-semibold text-slate-700 mb-1.5">
                Storage Location <span className="text-rose-600">*</span>
              </label>
              <input
                id="field-location"
                type="text"
                value={draft.location}
                onChange={(e) => updateField('location', e.target.value)}
                placeholder="e.g., Go-Bag Main Pocket"
                className={`w-full min-h-[44px] px-3.5 py-2 text-sm rounded-xl border bg-white text-slate-900 focus:outline-none focus:ring-2 ${
                  errors.location
                    ? 'border-rose-400 focus:ring-rose-200'
                    : 'border-slate-300 focus:border-slate-900 focus:ring-slate-200'
                }`}
              />
              {errors.location && <p className="mt-1 text-xs text-rose-600">{errors.location}</p>}
            </div>

            <div>
              <label htmlFor="field-expiry" className="block text-xs font-semibold text-slate-700 mb-1.5">
                Expiry / Review Date (Optional)
              </label>
              <input
                id="field-expiry"
                type="text"
                value={draft.expiryDate}
                onChange={(e) => updateField('expiryDate', e.target.value)}
                placeholder="YYYY-MM-DD"
                className={`w-full min-h-[44px] px-3.5 py-2 text-sm font-mono tabular-nums rounded-xl border bg-white text-slate-900 focus:outline-none focus:ring-2 ${
                  errors.expiryDate
                    ? 'border-rose-400 focus:ring-rose-200'
                    : 'border-slate-300 focus:border-slate-900 focus:ring-slate-200'
                }`}
              />
              {errors.expiryDate && (
                <p className="mt-1 text-xs text-rose-600">{errors.expiryDate}</p>
              )}
            </div>
          </div>

          <div>
            <label htmlFor="field-notes" className="block text-xs font-semibold text-slate-700 mb-1.5">
              Notes
            </label>
            <textarea
              id="field-notes"
              rows={2}
              value={draft.notes}
              onChange={(e) => updateField('notes', e.target.value)}
              placeholder="Rotation schedule, dosage, or packing instructions..."
              className={`w-full px-3.5 py-2.5 text-sm rounded-xl border bg-white text-slate-900 focus:outline-none focus:ring-2 ${
                errors.notes
                  ? 'border-rose-400 focus:ring-rose-200'
                  : 'border-slate-300 focus:border-slate-900 focus:ring-slate-200'
              }`}
            />
            {errors.notes && <p className="mt-1 text-xs text-rose-600">{errors.notes}</p>}
          </div>

          <label className="flex items-center gap-3 min-h-[44px] px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 cursor-pointer select-none">
            <input
              type="checkbox"
              checked={draft.completed}
              onChange={(e) => updateField('completed', e.target.checked)}
              className="w-5 h-5 rounded border-slate-300 text-orange-600 focus:ring-orange-500"
            />
            <span className="text-sm font-medium text-slate-800">
              Mark item as packed &amp; verified
            </span>
          </label>

          <div className="pt-2 pb-safe flex items-center justify-end gap-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="min-h-[44px] px-5 py-2.5 text-sm font-medium text-slate-700 hover:bg-slate-100 rounded-xl transition-colors whitespace-nowrap shrink-0"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="min-h-[44px] px-6 py-2.5 text-sm font-semibold text-white bg-orange-600 hover:bg-orange-700 active:scale-[0.98] rounded-xl inline-flex items-center gap-2 transition-all whitespace-nowrap shrink-0"
            >
              <CheckCircle2 className="w-4 h-4" aria-hidden="true" />
              <span>{editingItem ? 'Save Changes' : 'Save Item'}</span>
            </button>
          </div>
        </form>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
