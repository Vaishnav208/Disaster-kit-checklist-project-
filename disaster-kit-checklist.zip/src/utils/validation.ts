import {
  ImportRowLog,
  ImportSummary,
  KIT_CATEGORIES,
  KIT_PRIORITIES,
  KitCategory,
  KitItem,
  KitItemDraft,
  KitPriority,
  ValidationErrors,
  ValidationResult,
} from '../types/checklist';

// Strip control characters and collapse repeated whitespace
export function sanitizeText(value: unknown): string {
  if (typeof value !== 'string') {
    return '';
  }
  return value
    .replace(/[\u0000-\u001F\u007F]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

export function isValidIsoDate(dateStr: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) {
    return false;
  }
  const [yearStr, monthStr, dayStr] = dateStr.split('-');
  const year = Number(yearStr);
  const month = Number(monthStr);
  const day = Number(dayStr);

  if (year < 2020 || year > 2040) {
    return false;
  }

  const parsed = new Date(Date.UTC(year, month - 1, day));
  return (
    parsed.getUTCFullYear() === year &&
    parsed.getUTCMonth() === month - 1 &&
    parsed.getUTCDate() === day
  );
}

function parseStrictInteger(raw: string | number): number | null {
  if (typeof raw === 'number') {
    return Number.isInteger(raw) ? raw : null;
  }
  const cleaned = raw.trim();
  if (!/^-?\d+$/.test(cleaned)) {
    return null;
  }
  const parsed = Number(cleaned);
  return Number.isSafeInteger(parsed) ? parsed : null;
}

export function validateKitItemDraft(
  draft: KitItemDraft,
  existingItems: KitItem[] = [],
  editingId?: string
): ValidationResult {
  const errors: ValidationErrors = {};

  const name = sanitizeText(draft.name);
  if (!name) {
    errors.name = 'Item name is required and cannot be blank.';
  } else if (name.length < 2) {
    errors.name = 'Item name must be at least 2 characters.';
  } else if (name.length > 80) {
    errors.name = 'Item name must be 80 characters or fewer.';
  }

  const categoryRaw = sanitizeText(draft.category);
  const matchedCategory = KIT_CATEGORIES.find(
    (c) => c.toLowerCase() === categoryRaw.toLowerCase()
  );
  if (!matchedCategory) {
    errors.category = `Category must be one of: ${KIT_CATEGORIES.join(', ')}.`;
  }

  if (name && matchedCategory) {
    const duplicate = existingItems.find(
      (item) =>
        item.id !== editingId &&
        item.category === matchedCategory &&
        item.name.toLowerCase() === name.toLowerCase()
    );
    if (duplicate) {
      errors.name = `"${name}" already exists in ${matchedCategory}. Edit the existing entry instead.`;
    }
  }

  const priorityRaw = sanitizeText(draft.priority);
  const matchedPriority = KIT_PRIORITIES.find(
    (p) => p.toLowerCase() === priorityRaw.toLowerCase()
  );
  if (!matchedPriority) {
    errors.priority = `Priority must be ${KIT_PRIORITIES.join(', ')}.`;
  }

  const targetQty = parseStrictInteger(draft.targetQty);
  if (targetQty === null) {
    errors.targetQty = 'Target quantity must be a whole number (1–999).';
  } else if (targetQty < 1 || targetQty > 999) {
    errors.targetQty = 'Target quantity must be between 1 and 999.';
  }

  const packedQty = parseStrictInteger(draft.packedQty);
  if (packedQty === null) {
    errors.packedQty = 'Packed quantity must be a whole number (0–999).';
  } else if (packedQty < 0 || packedQty > 999) {
    errors.packedQty = 'Packed quantity must be between 0 and 999.';
  }

  const unit = sanitizeText(draft.unit);
  if (!unit) {
    errors.unit = 'Unit is required (e.g., liters, bottles, kits).';
  } else if (unit.length > 20) {
    errors.unit = 'Unit must be 20 characters or fewer.';
  } else if (!/^[a-zA-Z0-9\s\-/()]+$/.test(unit)) {
    errors.unit = 'Unit contains unsupported characters.';
  }

  const expiryDate = sanitizeText(draft.expiryDate);
  if (expiryDate && !isValidIsoDate(expiryDate)) {
    errors.expiryDate = 'Expiry date must be a valid YYYY-MM-DD date (2020–2040).';
  }

  const location = sanitizeText(draft.location);
  if (!location) {
    errors.location = 'Storage location is required.';
  } else if (location.length < 2 || location.length > 50) {
    errors.location = 'Storage location must be 2–50 characters.';
  }

  const notes = sanitizeText(draft.notes);
  if (notes.length > 220) {
    errors.notes = 'Notes must be 220 characters or fewer.';
  }

  if (Object.keys(errors).length > 0) {
    return { isValid: false, errors };
  }

  return {
    isValid: true,
    errors: {},
    sanitized: {
      name,
      category: matchedCategory as KitCategory,
      priority: matchedPriority as KitPriority,
      targetQty: targetQty as number,
      packedQty: packedQty as number,
      unit,
      completed: Boolean(draft.completed),
      expiryDate,
      location,
      notes,
    },
  };
}

// Validate arbitrary parsed JSON record (e.g. from localStorage or JSON import)
export function validateStoredRecord(
  raw: unknown,
  existingItems: KitItem[] = []
): { valid: boolean; item?: KitItem; errors: string[] } {
  if (!raw || typeof raw !== 'object') {
    return { valid: false, errors: ['Record is not a JSON object.'] };
  }

  const rec = raw as Record<string, unknown>;
  const draft: KitItemDraft = {
    name: typeof rec.name === 'string' ? rec.name : '',
    category: typeof rec.category === 'string' ? rec.category : '',
    priority: typeof rec.priority === 'string' ? rec.priority : '',
    targetQty:
      typeof rec.targetQty === 'number' || typeof rec.targetQty === 'string'
        ? rec.targetQty
        : '',
    packedQty:
      typeof rec.packedQty === 'number' || typeof rec.packedQty === 'string'
        ? rec.packedQty
        : '',
    unit: typeof rec.unit === 'string' ? rec.unit : '',
    completed: Boolean(rec.completed),
    expiryDate: typeof rec.expiryDate === 'string' ? rec.expiryDate : '',
    location: typeof rec.location === 'string' ? rec.location : '',
    notes: typeof rec.notes === 'string' ? rec.notes : '',
  };

  const result = validateKitItemDraft(draft, existingItems);
  if (!result.isValid || !result.sanitized) {
    return {
      valid: false,
      errors: Object.values(result.errors).filter((e): e is string => Boolean(e)),
    };
  }

  const id =
    typeof rec.id === 'string' && sanitizeText(rec.id)
      ? sanitizeText(rec.id)
      : `kit-${crypto.randomUUID().slice(0, 8)}`;

  const updatedAt =
    typeof rec.updatedAt === 'string' && !Number.isNaN(Date.parse(rec.updatedAt))
      ? rec.updatedAt
      : new Date().toISOString();

  return {
    valid: true,
    errors: [],
    item: {
      id,
      ...result.sanitized,
      updatedAt,
    },
  };
}

// RFC-4180 CSV parser handling quoted fields, commas, and escaped quotes
export function parseCsvMatrix(text: string): string[][] {
  const rows: string[][] = [];
  let currentRow: string[] = [];
  let currentCell = '';
  let inQuotes = false;

  const normalized = text.replace(/\r\n/g, '\n').replace(/\r/g, '\n');

  for (let i = 0; i < normalized.length; i++) {
    const char = normalized[i];
    const nextChar = normalized[i + 1];

    if (inQuotes) {
      if (char === '"' && nextChar === '"') {
        currentCell += '"';
        i++;
      } else if (char === '"') {
        inQuotes = false;
      } else {
        currentCell += char;
      }
    } else {
      if (char === '"') {
        inQuotes = true;
      } else if (char === ',') {
        currentRow.push(currentCell);
        currentCell = '';
      } else if (char === '\n') {
        currentRow.push(currentCell);
        if (currentRow.some((cell) => cell.trim() !== '')) {
          rows.push(currentRow);
        }
        currentRow = [];
        currentCell = '';
      } else {
        currentCell += char;
      }
    }
  }

  if (currentCell.length > 0 || currentRow.length > 0) {
    currentRow.push(currentCell);
    if (currentRow.some((cell) => cell.trim() !== '')) {
      rows.push(currentRow);
    }
  }

  return rows;
}

export function importDatasetText(
  rawText: string,
  format: 'csv' | 'json',
  currentItems: KitItem[],
  mode: 'merge' | 'replace'
): ImportSummary {
  const logs: ImportRowLog[] = [];
  const acceptedItems: KitItem[] = [];
  const baselineItems = mode === 'replace' ? [] : [...currentItems];

  if (format === 'json') {
    let parsed: unknown;
    try {
      parsed = JSON.parse(rawText);
    } catch {
      return {
        totalRows: 0,
        acceptedCount: 0,
        rejectedCount: 1,
        logs: [
          {
            rowNumber: 1,
            rawName: 'JSON Payload',
            status: 'rejected',
            messages: ['Malformed JSON syntax. Check brackets, quotes, and commas.'],
          },
        ],
        acceptedItems: [],
      };
    }

    const list = Array.isArray(parsed)
      ? parsed
      : parsed && typeof parsed === 'object' && Array.isArray((parsed as { items?: unknown[] }).items)
      ? (parsed as { items: unknown[] }).items
      : null;

    if (!list) {
      return {
        totalRows: 0,
        acceptedCount: 0,
        rejectedCount: 1,
        logs: [
          {
            rowNumber: 1,
            rawName: 'JSON Payload',
            status: 'rejected',
            messages: ['JSON root must be an array of records or { "items": [...] }.'],
          },
        ],
        acceptedItems: [],
      };
    }

    list.forEach((entry, index) => {
      const rawName =
        entry && typeof entry === 'object' && typeof (entry as { name?: unknown }).name === 'string'
          ? (entry as { name: string }).name
          : `Record #${index + 1}`;
      const res = validateStoredRecord(entry, [...baselineItems, ...acceptedItems]);
      if (res.valid && res.item) {
        acceptedItems.push(res.item);
        logs.push({
          rowNumber: index + 1,
          rawName: res.item.name,
          status: 'accepted',
          messages: ['Validated and queued for import.'],
        });
      } else {
        logs.push({
          rowNumber: index + 1,
          rawName,
          status: 'rejected',
          messages: res.errors,
        });
      }
    });

    return {
      totalRows: list.length,
      acceptedCount: acceptedItems.length,
      rejectedCount: list.length - acceptedItems.length,
      logs,
      acceptedItems,
    };
  }

  // CSV Import
  const matrix = parseCsvMatrix(rawText);
  if (matrix.length < 2) {
    return {
      totalRows: 0,
      acceptedCount: 0,
      rejectedCount: 1,
      logs: [
        {
          rowNumber: 1,
          rawName: 'CSV Header',
          status: 'rejected',
          messages: ['CSV must contain a header row and at least one data row.'],
        },
      ],
      acceptedItems: [],
    };
  }

  const headers = matrix[0].map((h) => h.trim().toLowerCase().replace(/[^a-z0-9]/g, ''));
  const colIndex = (aliases: string[]): number =>
    headers.findIndex((h) => aliases.includes(h));

  const idxName = colIndex(['name', 'item', 'itemname']);
  const idxCategory = colIndex(['category', 'cat']);
  const idxPriority = colIndex(['priority', 'severity']);
  const idxTarget = colIndex(['targetqty', 'target', 'qty', 'quantity']);
  const idxPacked = colIndex(['packedqty', 'packed', 'currentqty']);
  const idxUnit = colIndex(['unit', 'units']);
  const idxCompleted = colIndex(['completed', 'done', 'status']);
  const idxExpiry = colIndex(['expirydate', 'expiry', 'expiration', 'duedate']);
  const idxLocation = colIndex(['location', 'storagelocation', 'loc']);
  const idxNotes = colIndex(['notes', 'note', 'comments']);

  if (idxName === -1 || idxCategory === -1 || idxTarget === -1) {
    return {
      totalRows: matrix.length - 1,
      acceptedCount: 0,
      rejectedCount: matrix.length - 1,
      logs: [
        {
          rowNumber: 1,
          rawName: 'CSV Header',
          status: 'rejected',
          messages: [
            'Required columns missing. Ensure CSV header includes at least: name, category, targetQty.',
          ],
        },
      ],
      acceptedItems: [],
    };
  }

  const dataRows = matrix.slice(1);
  dataRows.forEach((row, index) => {
    const rowNumber = index + 2;
    const rawName = row[idxName] ?? `Row ${rowNumber}`;
    const completedRaw = (idxCompleted >= 0 ? row[idxCompleted] : '').trim().toLowerCase();
    const isCompleted =
      completedRaw === 'true' ||
      completedRaw === 'yes' ||
      completedRaw === '1' ||
      completedRaw === 'completed' ||
      completedRaw === 'done';

    const draft: KitItemDraft = {
      name: row[idxName] ?? '',
      category: row[idxCategory] ?? '',
      priority: idxPriority >= 0 ? row[idxPriority] ?? 'Essential' : 'Essential',
      targetQty: row[idxTarget] ?? '',
      packedQty: idxPacked >= 0 ? row[idxPacked] ?? '0' : '0',
      unit: idxUnit >= 0 ? row[idxUnit] ?? 'units' : 'units',
      completed: isCompleted,
      expiryDate: idxExpiry >= 0 ? row[idxExpiry] ?? '' : '',
      location: idxLocation >= 0 ? row[idxLocation] ?? 'Primary Kit' : 'Primary Kit',
      notes: idxNotes >= 0 ? row[idxNotes] ?? '' : '',
    };

    const result = validateKitItemDraft(draft, [...baselineItems, ...acceptedItems]);
    if (result.isValid && result.sanitized) {
      const item: KitItem = {
        id: `kit-${crypto.randomUUID().slice(0, 8)}`,
        ...result.sanitized,
        updatedAt: new Date().toISOString(),
      };
      acceptedItems.push(item);
      logs.push({
        rowNumber,
        rawName: item.name,
        status: 'accepted',
        messages: ['Row validated and ready to import.'],
      });
    } else {
      logs.push({
        rowNumber,
        rawName: sanitizeText(rawName) || `Row ${rowNumber}`,
        status: 'rejected',
        messages: Object.values(result.errors).filter((e): e is string => Boolean(e)),
      });
    }
  });

  return {
    totalRows: dataRows.length,
    acceptedCount: acceptedItems.length,
    rejectedCount: dataRows.length - acceptedItems.length,
    logs,
    acceptedItems,
  };
}
