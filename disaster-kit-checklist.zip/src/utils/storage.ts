import { SEED_ITEMS } from '../data/seedItems';
import { KitItem } from '../types/checklist';
import { validateStoredRecord } from './validation';

export const STORAGE_KEY = 'disaster_kit_checklist_v1';

export interface StorageLoadResult {
  items: KitItem[];
  recoveredFromError: boolean;
  recoveryMessage?: string;
}

export function loadChecklistFromStorage(): StorageLoadResult {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      saveChecklistToStorage(SEED_ITEMS);
      return {
        items: SEED_ITEMS,
        recoveredFromError: false,
      };
    }

    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) {
      throw new Error('Stored payload is not an array.');
    }

    const validItems: KitItem[] = [];
    let droppedCount = 0;

    for (const entry of parsed) {
      const check = validateStoredRecord(entry, validItems);
      if (check.valid && check.item) {
        validItems.push(check.item);
      } else {
        droppedCount++;
      }
    }

    if (validItems.length === 0 && parsed.length > 0) {
      throw new Error('All stored records failed schema validation.');
    }

    if (droppedCount > 0) {
      saveChecklistToStorage(validItems);
      return {
        items: validItems,
        recoveredFromError: true,
        recoveryMessage: `Recovered storage by filtering ${droppedCount} corrupted record${droppedCount === 1 ? '' : 's'}.`,
      };
    }

    return {
      items: validItems,
      recoveredFromError: false,
    };
  } catch {
    saveChecklistToStorage(SEED_ITEMS);
    return {
      items: SEED_ITEMS,
      recoveredFromError: true,
      recoveryMessage:
        'Detected corrupted or unreadable local storage. Automatically restored a clean 36-item checklist template.',
    };
  }
}

export function saveChecklistToStorage(items: KitItem[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
  } catch {
    // Ignore storage quota errors gracefully
  }
}

export function injectCorruptedStorageForDemo(): void {
  localStorage.setItem(STORAGE_KEY, '{"corrupted_json": [invalid_payload');
}

export function downloadTextFile(
  filename: string,
  content: string,
  mimeType = 'text/plain;charset=utf-8'
): void {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
