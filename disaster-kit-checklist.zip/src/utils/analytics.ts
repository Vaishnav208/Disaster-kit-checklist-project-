import {
  CategorySummary,
  KIT_CATEGORIES,
  KIT_PRIORITIES,
  KitItem,
  KitPriority,
  SummaryMetrics,
  ThresholdAlert,
} from '../types/checklist';

export function getTodayIsoDate(): string {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function daysUntilDate(isoDate: string, referenceIso = getTodayIsoDate()): number | null {
  if (!isoDate) return null;
  const target = Date.parse(`${isoDate}T00:00:00Z`);
  const ref = Date.parse(`${referenceIso}T00:00:00Z`);
  if (Number.isNaN(target) || Number.isNaN(ref)) return null;
  return Math.round((target - ref) / (1000 * 60 * 60 * 24));
}

export function computeItemReadiness(item: KitItem): number {
  if (item.targetQty <= 0) return 0;
  const ratio = Math.min(1, item.packedQty / item.targetQty);
  return Math.round(ratio * 100);
}

export function detectThresholdAlerts(
  items: KitItem[],
  referenceIso = getTodayIsoDate()
): ThresholdAlert[] {
  const alerts: ThresholdAlert[] = [];

  for (const item of items) {
    const daysLeft = daysUntilDate(item.expiryDate, referenceIso);

    if (daysLeft !== null && daysLeft < 0) {
      alerts.push({
        id: `alert-overdue-${item.id}`,
        itemId: item.id,
        itemName: item.name,
        category: item.category,
        type: 'overdue',
        severity: 'high',
        label: 'Overdue',
        detail: `Expired ${Math.abs(daysLeft)} day${Math.abs(daysLeft) === 1 ? '' : 's'} ago (${item.expiryDate}). Replace or re-inspect.`,
      });
    } else if (daysLeft !== null && daysLeft <= 30) {
      alerts.push({
        id: `alert-expiring-${item.id}`,
        itemId: item.id,
        itemName: item.name,
        category: item.category,
        type: 'expiring_soon',
        severity: 'medium',
        label: 'Expiring Soon',
        detail:
          daysLeft === 0
            ? `Expires today (${item.expiryDate}).`
            : `Expires in ${daysLeft} day${daysLeft === 1 ? '' : 's'} (${item.expiryDate}).`,
      });
    }

    const readiness = computeItemReadiness(item);
    if (item.priority === 'Critical' && (item.packedQty === 0 || readiness < 50)) {
      alerts.push({
        id: `alert-gap-${item.id}`,
        itemId: item.id,
        itemName: item.name,
        category: item.category,
        type: 'critical_gap',
        severity: 'high',
        label: 'Critical Gap',
        detail: `Packed ${item.packedQty} of ${item.targetQty} ${item.unit} (${readiness}%). Immediate restock advised.`,
      });
    }

    if (item.packedQty > item.targetQty) {
      alerts.push({
        id: `alert-anomaly-${item.id}`,
        itemId: item.id,
        itemName: item.name,
        category: item.category,
        type: 'anomaly',
        severity: 'info',
        label: 'Surplus',
        detail: `Packed ${item.packedQty} ${item.unit} exceeds target of ${item.targetQty} (+${item.packedQty - item.targetQty}).`,
      });
    } else if (item.completed && item.packedQty < item.targetQty) {
      alerts.push({
        id: `alert-anomaly-incomplete-${item.id}`,
        itemId: item.id,
        itemName: item.name,
        category: item.category,
        type: 'anomaly',
        severity: 'medium',
        label: 'Mismatch',
        detail: `Marked complete while packed quantity (${item.packedQty}) is below target (${item.targetQty}).`,
      });
    }
  }

  const severityOrder = { high: 0, medium: 1, info: 2 };
  return alerts.sort((a, b) => severityOrder[a.severity] - severityOrder[b.severity]);
}

export function computeSummaryMetrics(
  items: KitItem[],
  referenceIso = getTodayIsoDate()
): SummaryMetrics {
  const totalItems = items.length;
  const completedItems = items.filter((i) => i.completed).length;
  const incompleteItems = totalItems - completedItems;
  const overallCompletionRate =
    totalItems > 0 ? Math.round((completedItems / totalItems) * 100) : 0;

  const averageItemReadiness =
    totalItems > 0
      ? Math.round(items.reduce((acc, item) => acc + computeItemReadiness(item), 0) / totalItems)
      : 0;

  const totalTargetUnits = items.reduce((acc, item) => acc + item.targetQty, 0);
  const totalPackedUnits = items.reduce((acc, item) => acc + item.packedQty, 0);

  const criticalItems = items.filter((i) => i.priority === 'Critical');
  const criticalTotal = criticalItems.length;
  const criticalCompleted = criticalItems.filter((i) => i.completed).length;
  const criticalReadinessRate =
    criticalTotal > 0 ? Math.round((criticalCompleted / criticalTotal) * 100) : 100;

  const alerts = detectThresholdAlerts(items, referenceIso);
  const overdueCount = alerts.filter((a) => a.type === 'overdue').length;
  const expiringSoonCount = alerts.filter((a) => a.type === 'expiring_soon').length;
  const criticalGapCount = alerts.filter((a) => a.type === 'critical_gap').length;
  const anomalyCount = alerts.filter((a) => a.type === 'anomaly').length;

  const byCategory: CategorySummary[] = KIT_CATEGORIES.map((category) => {
    const catItems = items.filter((i) => i.category === category);
    const catTotal = catItems.length;
    const catCompleted = catItems.filter((i) => i.completed).length;
    const catTargetUnits = catItems.reduce((sum, i) => sum + i.targetQty, 0);
    const catPackedUnits = catItems.reduce((sum, i) => sum + Math.min(i.packedQty, i.targetQty), 0);

    return {
      category,
      totalItems: catTotal,
      completedItems: catCompleted,
      totalTargetUnits: catTargetUnits,
      totalPackedUnits: catItems.reduce((sum, i) => sum + i.packedQty, 0),
      completionRate: catTotal > 0 ? Math.round((catCompleted / catTotal) * 100) : 0,
      unitReadinessRate:
        catTargetUnits > 0 ? Math.round((catPackedUnits / catTargetUnits) * 100) : 0,
    };
  });

  const byPriority = KIT_PRIORITIES.reduce(
    (acc, priority) => {
      const pItems = items.filter((i) => i.priority === priority);
      const completed = pItems.filter((i) => i.completed).length;
      acc[priority] = {
        total: pItems.length,
        completed,
        rate: pItems.length > 0 ? Math.round((completed / pItems.length) * 100) : 0,
      };
      return acc;
    },
    {} as Record<KitPriority, { total: number; completed: number; rate: number }>
  );

  return {
    totalItems,
    completedItems,
    incompleteItems,
    overallCompletionRate,
    averageItemReadiness,
    totalTargetUnits,
    totalPackedUnits,
    criticalTotal,
    criticalCompleted,
    criticalReadinessRate,
    overdueCount,
    expiringSoonCount,
    criticalGapCount,
    anomalyCount,
    byCategory,
    byPriority,
  };
}

function escapeCsvCell(value: string | number | boolean): string {
  const str = String(value ?? '');
  if (/[",\n\r]/.test(str)) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

export function exportItemsToCsv(items: KitItem[]): string {
  const headers = [
    'id',
    'name',
    'category',
    'priority',
    'targetQty',
    'packedQty',
    'unit',
    'completed',
    'expiryDate',
    'location',
    'notes',
    'updatedAt',
  ];

  const rows = items.map((item) =>
    [
      item.id,
      item.name,
      item.category,
      item.priority,
      item.targetQty,
      item.packedQty,
      item.unit,
      item.completed,
      item.expiryDate,
      item.location,
      item.notes,
      item.updatedAt,
    ]
      .map(escapeCsvCell)
      .join(',')
  );

  return [headers.join(','), ...rows].join('\n');
}

export function exportSummaryToMarkdown(
  items: KitItem[],
  metrics: SummaryMetrics,
  alerts: ThresholdAlert[]
): string {
  const today = getTodayIsoDate();
  const lines: string[] = [
    `# Disaster Kit Checklist — Executive Summary`,
    ``,
    `Generated: ${today}`,
    ``,
    `## Key Readiness Metrics`,
    `- **Total Checklist Items:** ${metrics.totalItems}`,
    `- **Completed Items:** ${metrics.completedItems} (${metrics.overallCompletionRate}%)`,
    `- **Average Quantity Readiness:** ${metrics.averageItemReadiness}%`,
    `- **Critical Items Ready:** ${metrics.criticalCompleted}/${metrics.criticalTotal} (${metrics.criticalReadinessRate}%)`,
    `- **Units Packed / Target:** ${metrics.totalPackedUnits} / ${metrics.totalTargetUnits}`,
    ``,
    `## Category Breakdown`,
    `| Category | Items | Completed | Completion | Packed / Target Units |`,
    `| --- | ---: | ---: | ---: | ---: |`,
    ...metrics.byCategory.map(
      (cat) =>
        `| ${cat.category} | ${cat.totalItems} | ${cat.completedItems} | ${cat.completionRate}% | ${cat.totalPackedUnits} / ${cat.totalTargetUnits} |`
    ),
    ``,
    `## Threshold Warning Indicators (${alerts.length})`,
  ];

  if (alerts.length === 0) {
    lines.push(`- No overdue items, critical gaps, or anomalies detected.`);
  } else {
    alerts.forEach((alert) => {
      lines.push(`- **[${alert.label}] ${alert.itemName}** (${alert.category}): ${alert.detail}`);
    });
  }

  lines.push(``);
  lines.push(`## Incomplete Items (${metrics.incompleteItems})`);
  const incomplete = items.filter((i) => !i.completed);
  if (incomplete.length === 0) {
    lines.push(`- All items are packed and checked off.`);
  } else {
    incomplete.forEach((item) => {
      lines.push(
        `- [ ] **${item.name}** (${item.priority}) — ${item.packedQty}/${item.targetQty} ${item.unit} · ${item.location}`
      );
    });
  }

  return lines.join('\n');
}

export function exportAuditLogText(
  items: KitItem[],
  metrics: SummaryMetrics,
  alerts: ThresholdAlert[]
): string {
  const pad = (str: string, width: number) =>
    str.length >= width ? `${str.slice(0, width - 1)} ` : str.padEnd(width, ' ');

  const divider = '='.repeat(78);
  const subDivider = '-'.repeat(78);

  const out: string[] = [
    divider,
    'DISASTER KIT CHECKLIST — AUDIT LOG & INVENTORY REPORT',
    `Generated: ${new Date().toISOString()}`,
    divider,
    `Total Items      : ${metrics.totalItems}`,
    `Completed        : ${metrics.completedItems} (${metrics.overallCompletionRate}%)`,
    `Critical Ready   : ${metrics.criticalCompleted}/${metrics.criticalTotal} (${metrics.criticalReadinessRate}%)`,
    `Active Alerts    : ${alerts.length} (Overdue: ${metrics.overdueCount}, Critical Gaps: ${metrics.criticalGapCount})`,
    '',
    'CATEGORY SUMMARY',
    subDivider,
    `${pad('Category', 24)}${pad('Done/Total', 14)}${pad('Rate', 10)}${pad('Units', 18)}`,
    subDivider,
    ...metrics.byCategory.map(
      (c) =>
        `${pad(c.category, 24)}${pad(`${c.completedItems}/${c.totalItems}`, 14)}${pad(`${c.completionRate}%`, 10)}${pad(`${c.totalPackedUnits}/${c.totalTargetUnits}`, 18)}`
    ),
    '',
    'THRESHOLD WARNINGS',
    subDivider,
  ];

  if (alerts.length === 0) {
    out.push('None detected.');
  } else {
    alerts.forEach((a, i) => {
      out.push(`${String(i + 1).padStart(2, '0')}. [${a.label.toUpperCase()}] ${a.itemName} — ${a.detail}`);
    });
  }

  out.push('', 'FULL RECORD SNAPSHOT', subDivider);
  items.forEach((item) => {
    const check = item.completed ? '[X]' : '[ ]';
    const qty = `${item.packedQty}/${item.targetQty} ${item.unit}`;
    out.push(
      `${check} ${pad(item.name, 34)} ${pad(item.priority, 12)} ${pad(qty, 16)} ${item.expiryDate || 'No Expiry'}`
    );
  });
  out.push(divider);

  return out.join('\n');
}
