/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect, useMemo, useState } from 'react';
import {
  AlertTriangle,
  BarChart3,
  CheckCircle2,
  ClipboardCheck,
  Database,
  Plus,
  X,
} from 'lucide-react';
import { motion } from 'motion/react';
import { AlertsView } from './components/AlertsView';
import { ChecklistView } from './components/ChecklistView';
import { DataExportView } from './components/DataExportView';
import { ItemFormSheet } from './components/ItemFormSheet';
import { SummaryView } from './components/SummaryView';
import { SEED_ITEMS } from './data/seedItems';
import { AppTab, KitItem } from './types/checklist';
import { computeSummaryMetrics, detectThresholdAlerts } from './utils/analytics';
import {
  injectCorruptedStorageForDemo,
  loadChecklistFromStorage,
  saveChecklistToStorage,
} from './utils/storage';

const NAV_TABS: { id: AppTab; label: string }[] = [
  { id: 'checklist', label: 'Checklist' },
  { id: 'summary', label: 'Summary' },
  { id: 'alerts', label: 'Alerts' },
  { id: 'data', label: 'Data & Export' },
];

export default function App() {
  const [items, setItems] = useState<KitItem[]>([]);
  const [activeTab, setActiveTab] = useState<AppTab>('checklist');
  const [isSheetOpen, setIsSheetOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<KitItem | null>(null);
  const [notice, setNotice] = useState<{ type: 'info' | 'warning'; text: string } | null>(null);
  const [initialized, setInitialized] = useState(false);

  useEffect(() => {
    const loaded = loadChecklistFromStorage();
    setItems(loaded.items);
    setInitialized(true);
    if (loaded.recoveredFromError && loaded.recoveryMessage) {
      setNotice({ type: 'warning', text: loaded.recoveryMessage });
    }
  }, []);

  useEffect(() => {
    if (!initialized) return;
    saveChecklistToStorage(items);
  }, [items, initialized]);

  const alerts = useMemo(() => detectThresholdAlerts(items), [items]);
  const metrics = useMemo(() => computeSummaryMetrics(items), [items]);

  const showNotice = (text: string, type: 'info' | 'warning' = 'info') => {
    setNotice({ type, text });
  };

  const handleOpenAdd = () => {
    setEditingItem(null);
    setIsSheetOpen(true);
  };

  const handleOpenEdit = (item: KitItem) => {
    setEditingItem(item);
    setIsSheetOpen(true);
  };

  const handleSaveItem = (
    sanitized: Omit<KitItem, 'id' | 'updatedAt'>,
    editingId?: string
  ) => {
    const now = new Date().toISOString();
    if (editingId) {
      setItems((prev) =>
        prev.map((item) =>
          item.id === editingId ? { ...sanitized, id: editingId, updatedAt: now } : item
        )
      );
      showNotice(`Updated "${sanitized.name}" and saved locally.`);
    } else {
      const newItem: KitItem = {
        id: `kit-${crypto.randomUUID().slice(0, 8)}`,
        ...sanitized,
        updatedAt: now,
      };
      setItems((prev) => [newItem, ...prev]);
      showNotice(`Added "${sanitized.name}" to your disaster kit.`);
    }
  };

  const handleToggleComplete = (id: string) => {
    const now = new Date().toISOString();
    setItems((prev) =>
      prev.map((item) => {
        if (item.id !== id) return item;
        const nextCompleted = !item.completed;
        const nextPacked =
          nextCompleted && item.packedQty === 0 ? item.targetQty : item.packedQty;
        return {
          ...item,
          completed: nextCompleted,
          packedQty: nextPacked,
          updatedAt: now,
        };
      })
    );
  };

  const handleAdjustPacked = (id: string, delta: number) => {
    const now = new Date().toISOString();
    setItems((prev) =>
      prev.map((item) => {
        if (item.id !== id) return item;
        const nextPacked = Math.max(0, Math.min(999, item.packedQty + delta));
        const autoComplete = nextPacked >= item.targetQty;
        return {
          ...item,
          packedQty: nextPacked,
          completed: autoComplete ? true : nextPacked === 0 ? false : item.completed,
          updatedAt: now,
        };
      })
    );
  };

  const handleDeleteItem = (id: string) => {
    const target = items.find((i) => i.id === id);
    setItems((prev) => prev.filter((item) => item.id !== id));
    if (target) {
      showNotice(`Removed "${target.name}".`);
    }
  };

  const handleApplyImport = (importedItems: KitItem[], mode: 'merge' | 'replace') => {
    if (mode === 'replace') {
      setItems(importedItems);
      showNotice(`Replaced checklist with ${importedItems.length} validated items.`);
    } else {
      setItems((prev) => [...importedItems, ...prev]);
      showNotice(`Imported ${importedItems.length} validated items into your kit.`);
    }
    setActiveTab('checklist');
  };

  const handleResetSeed = () => {
    setItems(SEED_ITEMS);
    saveChecklistToStorage(SEED_ITEMS);
    showNotice('Restored the 36-item sample disaster kit dataset.');
  };

  const handleTestCorruptRecovery = () => {
    injectCorruptedStorageForDemo();
    const recovered = loadChecklistFromStorage();
    setItems(recovered.items);
    if (recovered.recoveryMessage) {
      showNotice(recovered.recoveryMessage, 'warning');
    }
  };

  const activeTitle =
    NAV_TABS.find((t) => t.id === activeTab)?.label ?? 'Disaster Kit Checklist';

  return (
    <div className="min-h-screen flex flex-col bg-[#F7F8FA] text-slate-900">
      {/* Desktop Top Bar (3-zone contract) */}
      <header className="hidden lg:block sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between gap-8">
          <button
            type="button"
            onClick={() => setActiveTab('checklist')}
            className="text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0"
            style={{ fontFamily: 'var(--font-display)' }}
          >
            Disaster Kit Checklist
          </button>

          <nav aria-label="Primary navigation" className="flex items-center gap-6">
            {NAV_TABS.map((tab) => {
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setActiveTab(tab.id)}
                  className={`min-h-[44px] px-1 text-sm font-medium border-b-2 transition-colors whitespace-nowrap shrink-0 ${
                    isActive
                      ? 'border-orange-600 text-slate-900 font-semibold'
                      : 'border-transparent text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {tab.id === 'alerts' && alerts.length > 0
                    ? `${tab.label} (${alerts.length})`
                    : tab.label}
                </button>
              );
            })}
          </nav>

          <button
            type="button"
            onClick={handleOpenAdd}
            className="min-h-[44px] px-4 py-2 text-sm font-semibold text-white bg-orange-600 hover:bg-orange-700 active:scale-[0.98] rounded-xl inline-flex items-center gap-1.5 transition-all whitespace-nowrap shrink-0"
          >
            <Plus className="w-4 h-4" aria-hidden="true" />
            <span>Add Item</span>
          </button>
        </div>
      </header>

      {/* Mobile Top App Bar (52px) */}
      <header className="lg:hidden sticky top-0 z-30 h-[52px] bg-white/95 backdrop-blur-md border-b border-slate-200 px-4 flex items-center justify-between gap-3">
        <span
          className="text-base font-bold tracking-tight text-slate-900 truncate"
          style={{ fontFamily: 'var(--font-display)' }}
        >
          {activeTab === 'checklist' ? 'Disaster Kit Checklist' : activeTitle}
        </span>
        <button
          type="button"
          onClick={handleOpenAdd}
          className="min-h-[40px] px-3 py-1.5 text-xs font-semibold text-white bg-orange-600 hover:bg-orange-700 rounded-xl inline-flex items-center gap-1 whitespace-nowrap shrink-0"
        >
          <Plus className="w-4 h-4" aria-hidden="true" />
          <span>Add Item</span>
        </button>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-5 pb-24 lg:pb-10 space-y-5">
        {/* Status / Recovery Notice */}
        {notice && (
          <div
            role="status"
            className={`px-4 py-3 rounded-xl border flex items-center justify-between gap-3 text-xs sm:text-sm ${
              notice.type === 'warning'
                ? 'bg-amber-50 border-amber-200 text-amber-900'
                : 'bg-emerald-50 border-emerald-200 text-emerald-900'
            }`}
          >
            <div className="flex items-center gap-2.5 min-w-0">
              {notice.type === 'warning' ? (
                <AlertTriangle className="w-4 h-4 text-amber-700 shrink-0" aria-hidden="true" />
              ) : (
                <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" aria-hidden="true" />
              )}
              <span className="truncate sm:whitespace-normal">{notice.text}</span>
            </div>
            <button
              type="button"
              onClick={() => setNotice(null)}
              aria-label="Dismiss notification"
              className="min-h-[36px] min-w-[36px] flex items-center justify-center rounded-lg hover:bg-black/5 shrink-0"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        <motion.div
          key={activeTab}
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.16, ease: [0.16, 1, 0.3, 1] }}
        >
          {activeTab === 'checklist' && (
            <ChecklistView
              items={items}
              alerts={alerts}
              onToggleComplete={handleToggleComplete}
              onAdjustPacked={handleAdjustPacked}
              onEditItem={handleOpenEdit}
              onDeleteItem={handleDeleteItem}
              onAddNew={handleOpenAdd}
            />
          )}

          {activeTab === 'summary' && (
            <SummaryView
              metrics={metrics}
              onGoToExport={() => setActiveTab('data')}
            />
          )}

          {activeTab === 'alerts' && (
            <AlertsView
              alerts={alerts}
              items={items}
              onEditItem={handleOpenEdit}
            />
          )}

          {activeTab === 'data' && (
            <DataExportView
              items={items}
              metrics={metrics}
              alerts={alerts}
              onApplyImport={handleApplyImport}
              onResetSeed={handleResetSeed}
              onTestCorruptRecovery={handleTestCorruptRecovery}
            />
          )}
        </motion.div>
      </main>

      {/* Mobile Fixed Bottom Tab Bar (64px) */}
      <nav
        aria-label="Mobile navigation"
        className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 pb-safe"
      >
        <div className="grid grid-cols-4 h-16">
          {(
            [
              { id: 'checklist', label: 'Checklist', Icon: ClipboardCheck },
              { id: 'summary', label: 'Summary', Icon: BarChart3 },
              {
                id: 'alerts',
                label: alerts.length > 0 ? `Alerts (${alerts.length})` : 'Alerts',
                Icon: AlertTriangle,
              },
              { id: 'data', label: 'Data', Icon: Database },
            ] as const
          ).map(({ id, label, Icon }) => {
            const isActive = activeTab === id;
            return (
              <button
                key={id}
                type="button"
                onClick={() => setActiveTab(id)}
                className={`min-h-[44px] flex flex-col items-center justify-center gap-0.5 px-1 transition-colors ${
                  isActive ? 'text-orange-600 font-semibold' : 'text-slate-500 hover:text-slate-900'
                }`}
              >
                <Icon className="w-5 h-5" aria-hidden="true" />
                <span className="text-[11px] leading-tight whitespace-nowrap truncate max-w-full">
                  {label}
                </span>
              </button>
            );
          })}
        </div>
      </nav>

      {/* Add / Edit Item Sheet */}
      <ItemFormSheet
        isOpen={isSheetOpen}
        editingItem={editingItem}
        existingItems={items}
        onClose={() => {
          setIsSheetOpen(false);
          setEditingItem(null);
        }}
        onSave={handleSaveItem}
      />
    </div>
  );
}
