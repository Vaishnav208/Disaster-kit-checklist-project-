export const KIT_CATEGORIES = [
  'Water & Food',
  'Medical & First Aid',
  'Power & Lighting',
  'Tools & Shelter',
  'Documents & Cash',
  'Hygiene & Sanitation',
  'Communication',
] as const;

export type KitCategory = (typeof KIT_CATEGORIES)[number];

export const KIT_PRIORITIES = ['Critical', 'Essential', 'Recommended'] as const;

export type KitPriority = (typeof KIT_PRIORITIES)[number];

export interface KitItem {
  id: string;
  name: string;
  category: KitCategory;
  priority: KitPriority;
  targetQty: number;
  packedQty: number;
  unit: string;
  completed: boolean;
  expiryDate: string; // YYYY-MM-DD or empty string if non-perishable
  location: string;
  notes: string;
  updatedAt: string; // ISO timestamp
}

export interface KitItemDraft {
  name: string;
  category: string;
  priority: string;
  targetQty: string | number;
  packedQty: string | number;
  unit: string;
  completed: boolean;
  expiryDate: string;
  location: string;
  notes: string;
}

export interface ValidationErrors {
  name?: string;
  category?: string;
  priority?: string;
  targetQty?: string;
  packedQty?: string;
  unit?: string;
  expiryDate?: string;
  location?: string;
  notes?: string;
}

export interface ValidationResult {
  isValid: boolean;
  errors: ValidationErrors;
  sanitized?: Omit<KitItem, 'id' | 'updatedAt'>;
}

export type AlertType = 'overdue' | 'expiring_soon' | 'critical_gap' | 'anomaly';

export type AlertSeverity = 'high' | 'medium' | 'info';

export interface ThresholdAlert {
  id: string;
  itemId: string;
  itemName: string;
  category: KitCategory;
  type: AlertType;
  severity: AlertSeverity;
  label: string;
  detail: string;
}

export interface CategorySummary {
  category: KitCategory;
  totalItems: number;
  completedItems: number;
  totalTargetUnits: number;
  totalPackedUnits: number;
  completionRate: number;
  unitReadinessRate: number;
}

export interface SummaryMetrics {
  totalItems: number;
  completedItems: number;
  incompleteItems: number;
  overallCompletionRate: number;
  averageItemReadiness: number;
  totalTargetUnits: number;
  totalPackedUnits: number;
  criticalTotal: number;
  criticalCompleted: number;
  criticalReadinessRate: number;
  overdueCount: number;
  expiringSoonCount: number;
  criticalGapCount: number;
  anomalyCount: number;
  byCategory: CategorySummary[];
  byPriority: Record<KitPriority, { total: number; completed: number; rate: number }>;
}

export interface ImportRowLog {
  rowNumber: number;
  rawName: string;
  status: 'accepted' | 'rejected';
  messages: string[];
}

export interface ImportSummary {
  totalRows: number;
  acceptedCount: number;
  rejectedCount: number;
  logs: ImportRowLog[];
  acceptedItems: KitItem[];
}

export type AppTab = 'checklist' | 'summary' | 'alerts' | 'data';
