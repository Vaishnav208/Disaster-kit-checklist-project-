import { KitCategory } from '../types/checklist';

export type DisasterId = 'earthquake' | 'flood' | 'wildfire' | 'blackout' | 'storm';

export interface DisasterScenario {
  id: DisasterId;
  label: string;
  immediateAction: string;
  kitNameKeywords: string[];
  priorityCategories: KitCategory[];
  essentialTakeChecklist: string[];
}

export interface NoSignalStep {
  stepNumber: string;
  title: string;
  action: string;
  relatedItemKeyword: string;
}

export const DISASTER_SCENARIOS: DisasterScenario[] = [
  {
    id: 'earthquake',
    label: 'Earthquake',
    immediateAction:
      'Drop, cover, and hold on until shaking stops. Expect aftershocks, check for gas leaks before using open flames, and wear sturdy shoes.',
    kitNameKeywords: [
      'Potable Drinking Water',
      'Gas & Water Utility Shut-Off Wrench',
      'N95 Particulate Respirator Masks',
      'Sterile Trauma Gauze',
      'LED Tactical Flashlights',
      'Pealess Emergency Signal Whistles',
      'Emergency Mylar Thermal Blankets',
      'Small-Denomination Cash Reserve',
    ],
    priorityCategories: ['Medical & First Aid', 'Tools & Shelter', 'Water & Food'],
    essentialTakeChecklist: [
      'Go-bag with water & high-calorie ration bars',
      'Utility shut-off wrench & sturdy work gloves',
      'N95 dust masks, trauma gauze & emergency whistle',
      'Flashlight, cash reserve & waterproof ID pouch',
    ],
  },
  {
    id: 'flood',
    label: 'Flood',
    immediateAction:
      'Move immediately to higher ground. Never walk or drive through floodwaters, and keep vital documents and electronics sealed dry.',
    kitNameKeywords: [
      'Waterproof Document Bag',
      'Potable Drinking Water',
      'Water Purification Tablets',
      'Heavy-Duty Contractor Trash Bags',
      'NOAA Hand-Crank Weather Radio',
      '20,000mAh USB-C Power Banks',
      'High-Calorie Ration Bars',
    ],
    priorityCategories: ['Documents & Cash', 'Water & Food', 'Communication'],
    essentialTakeChecklist: [
      'Waterproof document pouch (IDs, insurance, deeds)',
      'Sealed drinking water & purification tablets',
      'Contractor bags for waterproofing gear',
      'Crank weather radio & charged power bank',
    ],
  },
  {
    id: 'wildfire',
    label: 'Wildfire',
    immediateAction:
      'Evacuate early along pre-planned routes if advised. Protect airways from heavy smoke and grab your pre-packed go-bag and documents.',
    kitNameKeywords: [
      'N95 Particulate Respirator Masks',
      'Waterproof Document Bag',
      'Laminated Local Area & Evacuation Maps',
      'Prescription Medication',
      'Potable Drinking Water',
      'Small-Denomination Cash Reserve',
      'Two-Way GMRS Walkie-Talkie Pair',
    ],
    priorityCategories: ['Documents & Cash', 'Medical & First Aid', 'Communication'],
    essentialTakeChecklist: [
      'N95 respirator masks for smoke protection',
      'Laminated evacuation maps (in case GPS fails)',
      '7-day prescription medication & ID pouch',
      'Cash reserve, water & GMRS walkie-talkies',
    ],
  },
  {
    id: 'blackout',
    label: 'Power Outage',
    immediateAction:
      'Unplug sensitive appliances to prevent surge damage, use battery/crank lighting instead of candles, and keep fridge/freezer doors closed.',
    kitNameKeywords: [
      'LED Tactical Flashlights',
      'Lithium AA & AAA Battery Reserve',
      '20,000mAh USB-C Power Banks',
      'Foldable 28W Solar Charging Panel',
      '12-Hour Chemical Glow Sticks',
      'Manual Can Opener',
      'NOAA Hand-Crank Weather Radio',
    ],
    priorityCategories: ['Power & Lighting', 'Water & Food', 'Communication'],
    essentialTakeChecklist: [
      'LED flashlights & lithium spare batteries',
      '20,000mAh power banks & solar charging panel',
      'Zero-spark glow sticks & crank weather radio',
      'Manual can opener & shelf-stable food',
    ],
  },
  {
    id: 'storm',
    label: 'Severe Storm',
    immediateAction:
      'Shelter in an interior windowless room away from glass, monitor weather bulletins continuously, and prepare temporary rainproofing supplies.',
    kitNameKeywords: [
      'NOAA Hand-Crank Weather Radio',
      'Heavy-Duty 10x12 Waterproof Tarp',
      'Duct Tape Rolls',
      '550 Paracord Spool',
      'Potable Drinking Water',
      'Freeze-Dried Emergency Entrees',
      'ABC Dry Chemical Fire Extinguisher',
    ],
    priorityCategories: ['Tools & Shelter', 'Communication', 'Water & Food'],
    essentialTakeChecklist: [
      'NOAA weather radio for tornado/storm warnings',
      'Waterproof tarp, duct tape & 550 paracord',
      '72-hour potable water & emergency entrees',
      'Flashlights, charged power banks & fire extinguisher',
    ],
  },
];

export const NO_SIGNAL_STEPS: NoSignalStep[] = [
  {
    stepNumber: '01',
    title: 'Switch to Offline Weather & Emergency Radio',
    action:
      'Tune a hand-crank or battery AM/FM/NOAA radio for official evacuation routes, shelter locations, and boil-water notices without needing cell towers.',
    relatedItemKeyword: 'NOAA Hand-Crank Weather Radio',
  },
  {
    stepNumber: '02',
    title: 'Turn On Airplane Mode & Prefer Short SMS',
    action:
      'When there is no signal, constant tower searching drains phone batteries quickly. Keep Airplane Mode on and briefly toggle off every 30–60 minutes to send a short SMS text (texts often get through when voice calls fail).',
    relatedItemKeyword: '20,000mAh USB-C Power Banks',
  },
  {
    stepNumber: '03',
    title: 'Use Paper Evacuation Maps & Pre-Set Rally Points',
    action:
      'Follow your laminated local area map to your household meeting spot. If you leave home, leave a dated note inside a sealed bag stating where you went.',
    relatedItemKeyword: 'Laminated Local Area & Evacuation Maps',
  },
  {
    stepNumber: '04',
    title: 'Use Acoustic & Visual Distress Signals',
    action:
      'Three short blasts on an emergency whistle (or three short, three long, three short flashlight flashes at night) is the universal SOS distress signal.',
    relatedItemKeyword: 'Pealess Emergency Signal Whistles',
  },
  {
    stepNumber: '05',
    title: 'Coordinate Locally via Walkie-Talkies',
    action:
      'Use two-way GMRS/FRS radios on a pre-agreed household channel for short-range neighborhood check-ins when cellular networks are down.',
    relatedItemKeyword: 'Two-Way GMRS Walkie-Talkie Pair',
  },
];
